import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // jUG (1:23623)
        width: double.infinity,
        height: 640*fem,
        decoration: BoxDecoration (
          color: Color(0xfff7f7f7),
        ),
        child: Stack(
          children: [
            Positioned(
              // mobileticket2Sda (103:8785)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 412*fem,
                  height: 726*fem,
                  child: Image.asset(
                    'assets/page-1/images/mobile-ticket-2.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // excludeMVe (1:23657)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 360*fem,
                  height: 640*fem,
                  child: Image.asset(
                    'assets/page-1/images/exclude.png',
                    width: 360*fem,
                    height: 640*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle2UKN (1:23659)
              left: 75*fem,
              top: 149*fem,
              child: Align(
                child: SizedBox(
                  width: 210*fem,
                  height: 210*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(20*fem),
                      border: Border.all(color: Color(0xffffffff)),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // fabnL4 (1:23667)
              left: 154*fem,
              top: 394*fem,
              child: Align(
                child: SizedBox(
                  width: 52*fem,
                  height: 52*fem,
                  child: Image.asset(
                    'assets/page-1/images/fab.png',
                    width: 52*fem,
                    height: 52*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // frame10hC8 (1:23658)
              left: 51.5*fem,
              top: 58*fem,
              child: Container(
                width: 256*fem,
                height: 49*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // h5cpt (1:23630)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                      child: Text(
                        'Сканер',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 24*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1*ffem/fem,
                          letterSpacing: 0.1800000072*fem,
                          color: Color(0xddffffff),
                        ),
                      ),
                    ),
                    Text(
                      // subtitle1vKn (1:23631)
                      'поместите штрих-код в рамку',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.5*ffem/fem,
                        letterSpacing: 0.150000006*fem,
                        color: Color(0xddffffff),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // frame11eFn (1:23746)
              left: 58*fem,
              top: 493*fem,
              child: Container(
                width: 245*fem,
                height: 107*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // fabmrC (1:23628)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15*fem),
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(27*fem, 0*fem, 27*fem, 0*fem),
                          width: double.infinity,
                          height: 50*fem,
                          decoration: BoxDecoration (
                            color: Color(0xff56ccf2),
                            borderRadius: BorderRadius.circular(100*fem),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x33000000),
                                offset: Offset(0*fem, 3*fem),
                                blurRadius: 2.5*fem,
                              ),
                              BoxShadow(
                                color: Color(0x23000000),
                                offset: Offset(0*fem, 6*fem),
                                blurRadius: 5*fem,
                              ),
                              BoxShadow(
                                color: Color(0x1e000000),
                                offset: Offset(0*fem, 1*fem),
                                blurRadius: 9*fem,
                              ),
                            ],
                          ),
                          child: Container(
                            // baseoH6 (I1:23628;10003:114885)
                            width: double.infinity,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(100*fem),
                            ),
                            child: Center(
                              child: Text(
                                'ВВЕСТИ ID ВРУЧНУЮ',
                                style: SafeGoogleFont (
                                  'Roboto',
                                  fontSize: 15*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.7333333333*ffem/fem,
                                  letterSpacing: 0.4600000083*fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // buttongrg (1:23741)
                      margin: EdgeInsets.fromLTRB(38*fem, 0*fem, 38*fem, 0*fem),
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(5*fem, 8*fem, 4*fem, 8*fem),
                          width: double.infinity,
                          height: 42*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(4*fem),
                          ),
                          child: Container(
                            // baseNjW (I1:23741;5903:25821)
                            padding: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 0*fem),
                            width: double.infinity,
                            height: double.infinity,
                            child: Text(
                              'ВЕРНУТЬСЯ НАЗАД',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.7333333333*ffem/fem,
                                letterSpacing: 0.4600000083*fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}