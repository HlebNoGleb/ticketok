import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 280;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // Vik (103:8802)
        padding: EdgeInsets.fromLTRB(18*fem, 23*fem, 18*fem, 10*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          borderRadius: BorderRadius.circular(4*fem),
          boxShadow: [
            BoxShadow(
              color: Color(0x33000000),
              offset: Offset(0*fem, 8*fem),
              blurRadius: 5*fem,
            ),
            BoxShadow(
              color: Color(0x1e000000),
              offset: Offset(0*fem, 6*fem),
              blurRadius: 15*fem,
            ),
            BoxShadow(
              color: Color(0x23000000),
              offset: Offset(0*fem, 16*fem),
              blurRadius: 12*fem,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // dialogcontent8mi (103:8803)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15.5*fem, 20*fem),
              padding: EdgeInsets.fromLTRB(15.5*fem, 0*fem, 0*fem, 0*fem),
              child: Align(
                // bodyToz (103:8805)
                alignment: Alignment.centerRight,
                child: SizedBox(
                  child: Container(
                    constraints: BoxConstraints (
                      maxWidth: 201*fem,
                    ),
                    child: Text(
                      'Вы действительно хотите \nначать смену?',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.4285714286*ffem/fem,
                        letterSpacing: 0.25*fem,
                        color: Color(0x99000000),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // buttonsY4k (103:8806)
              width: double.infinity,
              height: 36*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // buttonscp (103:8807)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                    width: 100*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(4*fem),
                    ),
                    child: Center(
                      child: Center(
                        child: Text(
                          'ОТМЕНИТЬ',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1428571429*ffem/fem,
                            letterSpacing: 1.25*fem,
                            color: Color(0xffbb6bd9),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // buttonj9E (103:8808)
                    width: 136*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(4*fem),
                    ),
                    child: Center(
                      child: Center(
                        child: Text(
                          'НАЧАТЬ СМЕНУ',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1428571429*ffem/fem,
                            letterSpacing: 1.25*fem,
                            color: Color(0xff6200ee),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}