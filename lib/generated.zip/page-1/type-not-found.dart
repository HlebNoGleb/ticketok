import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // typenotfoundKsa (1:25788)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffcfcfc),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // toparegularaflatqL8 (1:25789)
              padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 16*fem),
              width: double.infinity,
              height: 56*fem,
              decoration: BoxDecoration (
                color: Color(0xff2196f3),
              ),
              child: Container(
                // autogroupakqysGp (2ggp3bDfEoDbEp7JzpAKQY)
                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 129*fem, 0*fem),
                width: 199*fem,
                height: double.infinity,
                child: Center(
                  child: Text(
                    'Работа с билетами',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.2*ffem/fem,
                      letterSpacing: 0.150000006*fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupekkw8iY (2ggoMCDJcEqWUaeaFvEkKW)
              padding: EdgeInsets.fromLTRB(30.5*fem, 10*fem, 31.5*fem, 25*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // buttonFYG (1:25793)
                    margin: EdgeInsets.fromLTRB(63*fem, 0*fem, 61*fem, 97*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(5*fem, 8*fem, 3*fem, 8*fem),
                        width: double.infinity,
                        height: 42*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(4*fem),
                        ),
                        child: Container(
                          // basewfz (I1:25793;5903:25926)
                          padding: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 0*fem),
                          width: double.infinity,
                          height: double.infinity,
                          child: Text(
                            'ЗАВЕРШИТЬ СМЕНУ',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.7333333333*ffem/fem,
                              letterSpacing: 0.4600000083*fem,
                              color: Color(0xffd32f2f),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // heroiconsoutlineswitchvertical (1:25794)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 25*fem),
                    width: 70*fem,
                    height: 70*fem,
                    child: Image.asset(
                      'assets/page-1/images/heroicons-outline-switch-vertical.png',
                      width: 70*fem,
                      height: 70*fem,
                    ),
                  ),
                  Container(
                    // frame9j64 (1:25790)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 38*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // h5qet (1:25791)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                          child: Text(
                            'Билет не найден',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              letterSpacing: 0.1800000072*fem,
                              color: Color(0xdd000000),
                            ),
                          ),
                        ),
                        Container(
                          // subtitle1LrY (1:25792)
                          constraints: BoxConstraints (
                            maxWidth: 298*fem,
                          ),
                          child: Text(
                            'Возможно, билет подделан. \nПроверьте ещё раз, при необходимости \nпозовите менеджера.',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              letterSpacing: 0.150000006*fem,
                              color: Color(0xdd000000),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroup4hojEh2 (2ggnnxe1nekKropozM4HoJ)
                    margin: EdgeInsets.fromLTRB(26.5*fem, 0*fem, 26.5*fem, 40*fem),
                    width: double.infinity,
                    height: 112*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // fabYxc (1:25856)
                          left: 0*fem,
                          top: 62*fem,
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              padding: EdgeInsets.fromLTRB(60.5*fem, 0*fem, 60.5*fem, 0*fem),
                              width: 245*fem,
                              height: 50*fem,
                              decoration: BoxDecoration (
                                color: Color(0xff2196f3),
                                borderRadius: BorderRadius.circular(100*fem),
                                boxShadow: [
                                  BoxShadow(
                                    color: Color(0x33000000),
                                    offset: Offset(0*fem, 3*fem),
                                    blurRadius: 2.5*fem,
                                  ),
                                  BoxShadow(
                                    color: Color(0x23000000),
                                    offset: Offset(0*fem, 6*fem),
                                    blurRadius: 5*fem,
                                  ),
                                  BoxShadow(
                                    color: Color(0x1e000000),
                                    offset: Offset(0*fem, 1*fem),
                                    blurRadius: 9*fem,
                                  ),
                                ],
                              ),
                              child: Container(
                                // baseYbE (I1:25856;10003:114885)
                                width: double.infinity,
                                height: double.infinity,
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(100*fem),
                                ),
                                child: Center(
                                  child: Text(
                                    'ПОВТОРИТЬ',
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 15*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.7333333333*ffem/fem,
                                      letterSpacing: 0.4600000083*fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // textfieldpHr (1:25858)
                          left: 0*fem,
                          top: 0*fem,
                          child: Container(
                            width: 245*fem,
                            height: 73*fem,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // inputvbn (I1:25858;5904:28116)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                  padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7.5*fem),
                                  width: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Center(
                                        // labeleGt (I1:25858;5904:28117)
                                        child: Container(
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5.5*fem),
                                          child: Text(
                                            'Штрих-код билета',
                                            textAlign: TextAlign.center,
                                            style: SafeGoogleFont (
                                              'Roboto',
                                              fontSize: 12*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1*ffem/fem,
                                              letterSpacing: 0.150000006*fem,
                                              color: Color(0xff2196f3),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // content8xk (I1:25858;5904:28118)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5.5*fem),
                                        padding: EdgeInsets.fromLTRB(56*fem, 0*fem, 0*fem, 0*fem),
                                        width: double.infinity,
                                        height: 24*fem,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // autogroupivrgeAQ (2ggo47sRSAiZqwsC1NivrG)
                                              width: 140*fem,
                                              height: double.infinity,
                                              child: Text(
                                                'AWQS-Q8QQ-O9IA',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 16*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.5*ffem/fem,
                                                  letterSpacing: 0.150000006*fem,
                                                  color: Color(0xdd000000),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // autogrouppgql85a (2ggoA2sEakQ2yFyrZ1PGQL)
                                              width: 49*fem,
                                              height: 24*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/auto-group-pgql.png',
                                                width: 49*fem,
                                                height: 24*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Text(
                                  // helpertext3iL (I1:25858;5904:28128;6626:50981)
                                  'Helper text',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.6600000064*ffem/fem,
                                    letterSpacing: 0.400000006*fem,
                                    color: Color(0x99000000),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // buttonA2G (1:25796)
                    margin: EdgeInsets.fromLTRB(71.5*fem, 0*fem, 70.5*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(52.5*fem, 4*fem, 34.5*fem, 4*fem),
                        width: double.infinity,
                        height: 30*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff2d9cdb),
                          borderRadius: BorderRadius.circular(4*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x33000000),
                              offset: Offset(0*fem, 3*fem),
                              blurRadius: 0.5*fem,
                            ),
                            BoxShadow(
                              color: Color(0x23000000),
                              offset: Offset(0*fem, 2*fem),
                              blurRadius: 1*fem,
                            ),
                            BoxShadow(
                              color: Color(0x1e000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 2.5*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // basewhE (I1:25796;5903:24607)
                          width: double.infinity,
                          height: double.infinity,
                          child: Container(
                            // autogroup8yxxWVS (2ggocgmVPbGUqNUFy88yxx)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                            padding: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                            width: 51*fem,
                            height: double.infinity,
                            child: Text(
                              'НАЗАД',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 13*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.6923076923*ffem/fem,
                                letterSpacing: 0.4600000083*fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}