import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 290;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // apiux8 (103:8792)
        width: double.infinity,
        height: 132*fem,
        child: Text(
          'Показывать модальное окно только если из API пришло больше одного мероприятия.\n\nЕсли пришло одно - установить его как основное автоматически.',
          style: SafeGoogleFont (
            'Roboto',
            fontSize: 13*ffem,
            fontWeight: FontWeight.w500,
            height: 1.6923076923*ffem/fem,
            letterSpacing: 0.4600000083*fem,
            color: Color(0xffffffff),
          ),
        ),
      ),
          );
  }
}