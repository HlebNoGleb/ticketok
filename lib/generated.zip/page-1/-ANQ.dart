import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // kS8 (1:25808)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfff7f7f7),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // toparegularaflatgKn (1:25809)
              padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 16*fem),
              width: double.infinity,
              height: 56*fem,
              decoration: BoxDecoration (
                color: Color(0xff2196f3),
              ),
              child: Container(
                // autogrouph7wcoQQ (2ggkANMbuyfitU56jXh7WC)
                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 129*fem, 0*fem),
                width: 199*fem,
                height: double.infinity,
                child: Center(
                  child: Text(
                    'Работа с билетами',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.2*ffem/fem,
                      letterSpacing: 0.150000006*fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupngrxGHz (2ggjaPLE8kfCp2Pz5XnGrx)
              padding: EdgeInsets.fromLTRB(54.5*fem, 239*fem, 54.5*fem, 25*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // frame9Bvk (1:25812)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 89*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // h5K1N (1:25813)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                          child: Text(
                            'Введите ID билета',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              letterSpacing: 0.1800000072*fem,
                              color: Color(0xdd000000),
                            ),
                          ),
                        ),
                        Text(
                          // subtitle1ox8 (1:25814)
                          'и нажмите кнопку отправить',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            letterSpacing: 0.150000006*fem,
                            color: Color(0xdd000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupfrxpLx4 (2ggizpTpmpj6heT13FfRxp)
                    margin: EdgeInsets.fromLTRB(2.5*fem, 0*fem, 3.5*fem, 40*fem),
                    width: double.infinity,
                    height: 112*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // fabfjS (1:25810)
                          left: 0*fem,
                          top: 62*fem,
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              padding: EdgeInsets.fromLTRB(61*fem, 0*fem, 61*fem, 0*fem),
                              width: 245*fem,
                              height: 50*fem,
                              decoration: BoxDecoration (
                                color: Color(0xff2196f3),
                                borderRadius: BorderRadius.circular(100*fem),
                                boxShadow: [
                                  BoxShadow(
                                    color: Color(0x33000000),
                                    offset: Offset(0*fem, 3*fem),
                                    blurRadius: 2.5*fem,
                                  ),
                                  BoxShadow(
                                    color: Color(0x23000000),
                                    offset: Offset(0*fem, 6*fem),
                                    blurRadius: 5*fem,
                                  ),
                                  BoxShadow(
                                    color: Color(0x1e000000),
                                    offset: Offset(0*fem, 1*fem),
                                    blurRadius: 9*fem,
                                  ),
                                ],
                              ),
                              child: Container(
                                // baseUwn (I1:25810;10003:114885)
                                width: double.infinity,
                                height: double.infinity,
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(100*fem),
                                ),
                                child: Center(
                                  child: Text(
                                    'ОТПРАВИТЬ',
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 15*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.7333333333*ffem/fem,
                                      letterSpacing: 0.4600000083*fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // textfieldxrx (1:25834)
                          left: 0*fem,
                          top: 0*fem,
                          child: Container(
                            width: 245*fem,
                            height: 73*fem,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // inputVbz (I1:25834;5904:28116)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                  padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7.5*fem),
                                  width: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Center(
                                        // labelp8U (I1:25834;5904:28117)
                                        child: Container(
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5.5*fem),
                                          child: Text(
                                            'Штрих-код билета',
                                            textAlign: TextAlign.center,
                                            style: SafeGoogleFont (
                                              'Roboto',
                                              fontSize: 12*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1*ffem/fem,
                                              letterSpacing: 0.150000006*fem,
                                              color: Color(0xff2196f3),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // content7NU (I1:25834;5904:28118)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5.5*fem),
                                        padding: EdgeInsets.fromLTRB(56*fem, 0*fem, 0*fem, 0*fem),
                                        width: double.infinity,
                                        height: 24*fem,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // autogroupssk2ECC (2ggjG9MczFvhscP2uNSsK2)
                                              width: 140*fem,
                                              height: double.infinity,
                                              child: Text(
                                                'AWQS-Q8QQ-O9IA',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 16*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.5*ffem/fem,
                                                  letterSpacing: 0.150000006*fem,
                                                  color: Color(0xdd000000),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // autogroup1zusWvQ (2ggjNeAo83ux9p7Uup1zuS)
                                              width: 49*fem,
                                              height: 24*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/auto-group-1zus.png',
                                                width: 49*fem,
                                                height: 24*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Text(
                                  // helpertext39e (I1:25834;5904:28128;6626:50981)
                                  'Helper text',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.6600000064*ffem/fem,
                                    letterSpacing: 0.400000006*fem,
                                    color: Color(0x99000000),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // buttonAVA (1:25829)
                    margin: EdgeInsets.fromLTRB(47.5*fem, 0*fem, 47.5*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(52.5*fem, 4*fem, 34.5*fem, 4*fem),
                        width: double.infinity,
                        height: 30*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff2d9cdb),
                          borderRadius: BorderRadius.circular(4*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x33000000),
                              offset: Offset(0*fem, 3*fem),
                              blurRadius: 0.5*fem,
                            ),
                            BoxShadow(
                              color: Color(0x23000000),
                              offset: Offset(0*fem, 2*fem),
                              blurRadius: 1*fem,
                            ),
                            BoxShadow(
                              color: Color(0x1e000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 2.5*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // basePsi (I1:25829;5903:24607)
                          width: double.infinity,
                          height: double.infinity,
                          child: Container(
                            // autogroupybgxANg (2ggk2xQHf8uy5iwZa6ybGx)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                            padding: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                            width: 51*fem,
                            height: double.infinity,
                            child: Text(
                              'НАЗАД',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 13*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.6923076923*ffem/fem,
                                letterSpacing: 0.4600000083*fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}