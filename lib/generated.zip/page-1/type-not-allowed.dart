import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // typenotallowedqQ8 (1:23870)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffcfcfc),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // toparegularaflatxDr (1:23871)
              padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 16*fem),
              width: double.infinity,
              height: 56*fem,
              decoration: BoxDecoration (
                color: Color(0xff2196f3),
              ),
              child: Container(
                // autogroupdojiUhz (2ggnHDzZUq7d3RMqR6doji)
                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 129*fem, 0*fem),
                width: 199*fem,
                height: double.infinity,
                child: Center(
                  child: Text(
                    'Работа с билетами',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.2*ffem/fem,
                      letterSpacing: 0.150000006*fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupv7taZDe (2ggmnVKSaWs7LzEmvNv7Ta)
              padding: EdgeInsets.fromLTRB(30*fem, 10*fem, 31*fem, 25*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // buttonUrQ (1:23877)
                    margin: EdgeInsets.fromLTRB(63.5*fem, 0*fem, 61.5*fem, 97*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(5*fem, 8*fem, 3*fem, 8*fem),
                        width: double.infinity,
                        height: 42*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(4*fem),
                        ),
                        child: Container(
                          // base9xY (I1:23877;5903:25926)
                          padding: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 0*fem),
                          width: double.infinity,
                          height: double.infinity,
                          child: Text(
                            'ЗАВЕРШИТЬ СМЕНУ',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.7333333333*ffem/fem,
                              letterSpacing: 0.4600000083*fem,
                              color: Color(0xffd32f2f),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // heroiconsoutlineswitchvertical (1:23895)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 25*fem),
                    width: 70*fem,
                    height: 70*fem,
                    child: Image.asset(
                      'assets/page-1/images/heroicons-outline-switch-vertical-eAx.png',
                      width: 70*fem,
                      height: 70*fem,
                    ),
                  ),
                  Container(
                    // frame9kSY (1:23874)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 190*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // h5gb6 (1:23875)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                          child: Text(
                            'Невалидный билет',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              letterSpacing: 0.1800000072*fem,
                              color: Color(0xdd000000),
                            ),
                          ),
                        ),
                        Container(
                          // subtitle1zLt (1:23876)
                          constraints: BoxConstraints (
                            maxWidth: 299*fem,
                          ),
                          child: Text(
                            'Категория билета не соответствует разрешённым для данного сканера. Объясните гостю, где он может обменять свой билет.',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              letterSpacing: 0.150000006*fem,
                              color: Color(0xdd000000),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // buttonVHe (1:23897)
                    margin: EdgeInsets.fromLTRB(72*fem, 0*fem, 71*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: double.infinity,
                        height: 30*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff2d9cdb),
                          borderRadius: BorderRadius.circular(4*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x33000000),
                              offset: Offset(0*fem, 3*fem),
                              blurRadius: 0.5*fem,
                            ),
                            BoxShadow(
                              color: Color(0x23000000),
                              offset: Offset(0*fem, 2*fem),
                              blurRadius: 1*fem,
                            ),
                            BoxShadow(
                              color: Color(0x1e000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 2.5*fem,
                            ),
                          ],
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              // baseWyS (I1:23897;5903:24607)
                              left: 52.5*fem,
                              top: 4*fem,
                              child: Container(
                                width: 69*fem,
                                height: 22*fem,
                                child: Container(
                                  // autogroup5xyzepk (2ggn2ERYQENkF7D7FA5xyz)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                                  width: 51*fem,
                                  height: double.infinity,
                                  child: Text(
                                    'НАЗАД',
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 13*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.6923076923*ffem/fem,
                                      letterSpacing: 0.4600000083*fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // buttonWrx (1:25846)
                              left: 0*fem,
                              top: 0*fem,
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(52.5*fem, 4*fem, 34.5*fem, 4*fem),
                                  width: 156*fem,
                                  height: 30*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xff2d9cdb),
                                    borderRadius: BorderRadius.circular(4*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x33000000),
                                        offset: Offset(0*fem, 3*fem),
                                        blurRadius: 0.5*fem,
                                      ),
                                      BoxShadow(
                                        color: Color(0x23000000),
                                        offset: Offset(0*fem, 2*fem),
                                        blurRadius: 1*fem,
                                      ),
                                      BoxShadow(
                                        color: Color(0x1e000000),
                                        offset: Offset(0*fem, 1*fem),
                                        blurRadius: 2.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Container(
                                    // basevQt (I1:25846;5903:24607)
                                    width: double.infinity,
                                    height: double.infinity,
                                    child: Container(
                                      // autogroupq5yp6KN (2ggnAPrcDCfePZr5iUq5Yp)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                                      padding: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                                      width: 51*fem,
                                      height: double.infinity,
                                      child: Text(
                                        'НАЗАД',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 13*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.6923076923*ffem/fem,
                                          letterSpacing: 0.4600000083*fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}