import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // ipk (1:3485)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffcfcfc),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // toparegularaflatEo6 (1:3529)
              padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 16*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xff2196f3),
              ),
              child: Text(
                'Профиль работника',
                style: SafeGoogleFont (
                  'Roboto',
                  fontSize: 20*ffem,
                  fontWeight: FontWeight.w500,
                  height: 1.2*ffem/fem,
                  letterSpacing: 0.150000006*fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // fixedatextHmN (1:8111)
              width: double.infinity,
              height: 48*fem,
              decoration: BoxDecoration (
                color: Color(0xff2196f3),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // tablstatesQ5J (I1:8111;242:8097)
                    padding: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 0*fem),
                    width: 120*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xff2196f3),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // tabW8L (I1:8111;242:8097;242:8069)
                          margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 14*fem),
                          child: Text(
                            'ГЛАВНАЯ',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              letterSpacing: 1.25*fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                        Container(
                          // indicatorbvU (I1:8111;242:8097;242:8068)
                          width: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff2196f3),
                          ),
                          child: Center(
                            // indicatorZcQ (I1:8111;242:8097;242:8068;242:8071)
                            child: SizedBox(
                              width: double.infinity,
                              height: 2*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // tablstatestua (I1:8111;242:8098)
                    width: 120*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xff2196f3),
                    ),
                    child: Center(
                      child: Text(
                        'ИНФО',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.1428571429*ffem/fem,
                          letterSpacing: 1.25*fem,
                          color: Color(0xbcffffff),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // tablstatesyAL (I1:8111;242:8099)
                    width: 120*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xff2196f3),
                    ),
                    child: Center(
                      child: Text(
                        'НАСТРОЙКИ',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.1428571429*ffem/fem,
                          letterSpacing: 1.25*fem,
                          color: Color(0xbcffffff),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupkzbsqTS (2ggWoAnwq9qMp5M5kTkZBS)
              padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 16*fem, 16*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // alertZ8Y (102:12684)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15*fem),
                    padding: EdgeInsets.fromLTRB(16*fem, 10*fem, 16*fem, 8*fem),
                    width: double.infinity,
                    height: 48*fem,
                    decoration: BoxDecoration (
                      color: Color(0xffe5f6fd),
                      borderRadius: BorderRadius.circular(4*fem),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // iconcontainerdu6 (I102:12684;5903:35272)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 2*fem),
                          width: 22*fem,
                          height: 22*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-container-r12.png',
                            width: 22*fem,
                            height: 22*fem,
                          ),
                        ),
                        Container(
                          // textjx8 (I102:12684;5903:35274)
                          margin: EdgeInsets.fromLTRB(0*fem, 4*fem, 69*fem, 2*fem),
                          height: double.infinity,
                          child: Text(
                            'Viva Braslav 2023 ',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.4299998965*ffem/fem,
                              letterSpacing: 0.1700000018*fem,
                              color: Color(0xff014361),
                            ),
                          ),
                        ),
                        Container(
                          // onclosecontainerpya (I102:12684;5903:35277)
                          width: 75*fem,
                          height: double.infinity,
                          child: TextButton(
                            // buttonyrU (I102:12684;5903:35278)
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 1*fem, 4*fem),
                              width: double.infinity,
                              height: double.infinity,
                              decoration: BoxDecoration (
                                borderRadius: BorderRadius.circular(4*fem),
                              ),
                              child: Container(
                                // basei3N (I102:12684;5903:35278;9996:110169)
                                padding: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                                width: double.infinity,
                                height: double.infinity,
                                child: Text(
                                  'СМЕНИТЬ',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 13*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.6923076923*ffem/fem,
                                    letterSpacing: 0.4600000083*fem,
                                    color: Color(0xff014361),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // frame6CUL (1:6774)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 106*fem, 15*fem),
                    width: double.infinity,
                    height: 50*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // maskgroupKor (1:23737)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                          width: 50*fem,
                          height: 50*fem,
                          child: Image.asset(
                            'assets/page-1/images/mask-group.png',
                            width: 50*fem,
                            height: 50*fem,
                          ),
                        ),
                        Container(
                          // frame5qXJ (1:6773)
                          margin: EdgeInsets.fromLTRB(0*fem, 7.5*fem, 0*fem, 7*fem),
                          width: 162*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // subtitle1Nn8 (1:3740)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 162*fem,
                                    height: 19*fem,
                                    child: Text(
                                      'Снежана Тихонова',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        letterSpacing: 0.150000006*fem,
                                        color: Color(0xdd000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // subtitle23tG (1:3741)
                                left: 0*fem,
                                top: 18.5*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 100*fem,
                                    height: 17*fem,
                                    child: Text(
                                      'Оператор №1',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        letterSpacing: 0.150000006*fem,
                                        color: Color(0x99000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // frame89Ac (1:8072)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 26*fem, 222*fem),
                    width: 302*fem,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // subtitle3UCt (1:8070)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                          child: Text(
                            'Разрешённые сектора',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              letterSpacing: 0.150000006*fem,
                              color: Color(0x99000000),
                            ),
                          ),
                        ),
                        Container(
                          // frame7b2c (1:8071)
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // autogroupbbcp8oE (2ggX5zeF9r7FfUHzENbBCp)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 10*fem),
                                width: double.infinity,
                                height: 24*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // chipTac (1:7471)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                      child: TextButton(
                                        onPressed: () {},
                                        style: TextButton.styleFrom (
                                          padding: EdgeInsets.zero,
                                        ),
                                        child: Container(
                                          padding: EdgeInsets.fromLTRB(10*fem, 3*fem, 0*fem, 3*fem),
                                          width: 111*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xff2196f3),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: Container(
                                            // typography7QG (I1:7471;6588:47879)
                                            width: double.infinity,
                                            height: double.infinity,
                                            child: Center(
                                              child: Text(
                                                'Кемпинг 4 дня',
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 13*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.3846153846*ffem/fem,
                                                  letterSpacing: 0.1599999964*fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    TextButton(
                                      // chipCRi (1:8054)
                                      onPressed: () {},
                                      style: TextButton.styleFrom (
                                        padding: EdgeInsets.zero,
                                      ),
                                      child: Container(
                                        padding: EdgeInsets.fromLTRB(10*fem, 3*fem, 0*fem, 3*fem),
                                        width: 169*fem,
                                        height: double.infinity,
                                        decoration: BoxDecoration (
                                          color: Color(0xff2196f3),
                                          borderRadius: BorderRadius.circular(100*fem),
                                        ),
                                        child: Container(
                                          // typography7Yg (I1:8054;6588:47879)
                                          width: 160*fem,
                                          height: double.infinity,
                                          child: Center(
                                            child: Text(
                                              'Глэмпинг Comfort 4 дня',
                                              style: SafeGoogleFont (
                                                'Roboto',
                                                fontSize: 13*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.3846153846*ffem/fem,
                                                letterSpacing: 0.1599999964*fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // autogrouppdqqcEY (2ggXMEhr5phBF2HCAwpDQQ)
                                width: double.infinity,
                                height: 24*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // chipkrY (1:8060)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                      child: TextButton(
                                        onPressed: () {},
                                        style: TextButton.styleFrom (
                                          padding: EdgeInsets.zero,
                                        ),
                                        child: Container(
                                          padding: EdgeInsets.fromLTRB(10*fem, 3*fem, 0*fem, 3*fem),
                                          width: 159*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xff2196f3),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: Container(
                                            // typographySUU (I1:8060;6588:47879)
                                            width: 150*fem,
                                            height: double.infinity,
                                            child: Center(
                                              child: Text(
                                                'Глэмпинг Luxary 4 дня',
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 13*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.3846153846*ffem/fem,
                                                  letterSpacing: 0.1599999964*fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    TextButton(
                                      // chipYnQ (1:8065)
                                      onPressed: () {},
                                      style: TextButton.styleFrom (
                                        padding: EdgeInsets.zero,
                                      ),
                                      child: Container(
                                        padding: EdgeInsets.fromLTRB(10*fem, 3*fem, 4*fem, 3*fem),
                                        width: 133*fem,
                                        height: double.infinity,
                                        decoration: BoxDecoration (
                                          color: Color(0xff2196f3),
                                          borderRadius: BorderRadius.circular(100*fem),
                                        ),
                                        child: Container(
                                          // typographyfs2 (I1:8065;6588:47879)
                                          width: double.infinity,
                                          height: double.infinity,
                                          child: Center(
                                            child: Text(
                                              'Авто Garage 4 дня',
                                              style: SafeGoogleFont (
                                                'Roboto',
                                                fontSize: 13*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.3846153846*ffem/fem,
                                                letterSpacing: 0.1599999964*fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // subtitle4NmS (1:22771)
                    margin: EdgeInsets.fromLTRB(32*fem, 0*fem, 0*fem, 14*fem),
                    child: Text(
                      'Чтобы начать работу, нажмите кнопку ниже',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 12*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.1725*ffem/fem,
                        letterSpacing: 0.150000006*fem,
                        color: Color(0x99000000),
                      ),
                    ),
                  ),
                  TextButton(
                    // button5fr (1:22777)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      padding: EdgeInsets.fromLTRB(98.5*fem, 8*fem, 99.5*fem, 8*fem),
                      width: double.infinity,
                      height: 42*fem,
                      decoration: BoxDecoration (
                        color: Color(0xff2e7d32),
                        borderRadius: BorderRadius.circular(4*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x33000000),
                            offset: Offset(0*fem, 3*fem),
                            blurRadius: 0.5*fem,
                          ),
                          BoxShadow(
                            color: Color(0x23000000),
                            offset: Offset(0*fem, 2*fem),
                            blurRadius: 1*fem,
                          ),
                          BoxShadow(
                            color: Color(0x1e000000),
                            offset: Offset(0*fem, 1*fem),
                            blurRadius: 2.5*fem,
                          ),
                        ],
                      ),
                      child: Container(
                        // baseXGx (I1:22777;5903:24127)
                        padding: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 0*fem),
                        width: double.infinity,
                        height: double.infinity,
                        child: Text(
                          'НАЧАТЬ CМЕНУ',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.7333333333*ffem/fem,
                            letterSpacing: 0.4600000083*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}