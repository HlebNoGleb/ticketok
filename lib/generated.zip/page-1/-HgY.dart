import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // EHJ (1:23847)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffcfcfc),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // toparegularaflatM72 (1:23848)
              padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 16*fem),
              width: double.infinity,
              height: 56*fem,
              decoration: BoxDecoration (
                color: Color(0xff2196f3),
              ),
              child: Container(
                // autogroupg2owftQ (2ggmGRMD8rmg9wzVexG2oW)
                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 129*fem, 0*fem),
                width: 199*fem,
                height: double.infinity,
                child: Center(
                  child: Text(
                    'Работа с билетами',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.2*ffem/fem,
                      letterSpacing: 0.150000006*fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupzesewb2 (2ggkvr5VT2CFivrKi5zEse)
              padding: EdgeInsets.fromLTRB(57*fem, 10*fem, 58*fem, 95*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // button4fe (1:23854)
                    margin: EdgeInsets.fromLTRB(36.5*fem, 0*fem, 34.5*fem, 97*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(5*fem, 8*fem, 3*fem, 8*fem),
                        width: double.infinity,
                        height: 42*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(4*fem),
                        ),
                        child: Container(
                          // baseZ6c (I1:23854;5903:25926)
                          padding: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 0*fem),
                          width: double.infinity,
                          height: double.infinity,
                          child: Text(
                            'ЗАВЕРШИТЬ СМЕНУ',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.7333333333*ffem/fem,
                              letterSpacing: 0.4600000083*fem,
                              color: Color(0xffd32f2f),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // heroiconsoutlineswitchvertical (1:23868)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 27*fem),
                    width: 70*fem,
                    height: 70*fem,
                    child: Image.asset(
                      'assets/page-1/images/heroicons-outline-switch-vertical-CNY.png',
                      width: 70*fem,
                      height: 70*fem,
                    ),
                  ),
                  Container(
                    // frame9ZF2 (1:23851)
                    margin: EdgeInsets.fromLTRB(25*fem, 0*fem, 24*fem, 82*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // h5tHJ (1:23852)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                          child: Text(
                            'Вход разрешён',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              letterSpacing: 0.1800000072*fem,
                              color: Color(0xdd000000),
                            ),
                          ),
                        ),
                        Text(
                          // subtitle1bBi (1:23853)
                          'Наденьте гостю браслет.',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.150000006*fem,
                            color: Color(0xdd000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // fab7fr (1:23850)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(27*fem, 0*fem, 27*fem, 0*fem),
                        width: double.infinity,
                        height: 50*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff56ccf2),
                          borderRadius: BorderRadius.circular(100*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x33000000),
                              offset: Offset(0*fem, 3*fem),
                              blurRadius: 2.5*fem,
                            ),
                            BoxShadow(
                              color: Color(0x23000000),
                              offset: Offset(0*fem, 6*fem),
                              blurRadius: 5*fem,
                            ),
                            BoxShadow(
                              color: Color(0x1e000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 9*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // basevNQ (I1:23850;10003:114885)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'ВВЕСТИ ID ВРУЧНУЮ',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.7333333333*ffem/fem,
                                letterSpacing: 0.4600000083*fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  TextButton(
                    // fabpCt (1:23849)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      padding: EdgeInsets.fromLTRB(37.5*fem, 0*fem, 37.5*fem, 0*fem),
                      width: double.infinity,
                      height: 50*fem,
                      decoration: BoxDecoration (
                        color: Color(0xff2196f3),
                        borderRadius: BorderRadius.circular(100*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x33000000),
                            offset: Offset(0*fem, 3*fem),
                            blurRadius: 2.5*fem,
                          ),
                          BoxShadow(
                            color: Color(0x23000000),
                            offset: Offset(0*fem, 6*fem),
                            blurRadius: 5*fem,
                          ),
                          BoxShadow(
                            color: Color(0x1e000000),
                            offset: Offset(0*fem, 1*fem),
                            blurRadius: 9*fem,
                          ),
                        ],
                      ),
                      child: Container(
                        // base4N8 (I1:23849;10003:114885)
                        width: double.infinity,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(100*fem),
                        ),
                        child: Center(
                          child: Text(
                            'ОТКРЫТЬ СКАНЕР',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.7333333333*ffem/fem,
                              letterSpacing: 0.4600000083*fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}