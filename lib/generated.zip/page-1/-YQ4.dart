import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // AKe (159:8810)
        width: double.infinity,
        height: 640*fem,
        decoration: BoxDecoration (
          color: Color(0xfffcfcfc),
        ),
        child: Stack(
          children: [
            Positioned(
              // frame2tWY (159:8811)
              left: 16*fem,
              top: 315*fem,
              child: Container(
                width: 328*fem,
                height: 152*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // frame115N (159:8812)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 328*fem,
                        height: 124*fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // textfieldvi8 (159:8813)
                              left: 0*fem,
                              top: 0*fem,
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  width: 328*fem,
                                  height: 71*fem,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // inputSRa (I159:8813;5904:28224)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                                        width: double.infinity,
                                        height: 46*fem,
                                        child: Container(
                                          // autogroupvk6gBPA (2ggTu189tfi6tXprrtvk6G)
                                          padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                                          width: double.infinity,
                                          height: 45*fem,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // templabel9zC (I159:8813;5904:28225)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                child: Text(
                                                  'Label',
                                                  style: SafeGoogleFont (
                                                    'Roboto',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1*ffem/fem,
                                                    letterSpacing: 0.150000006*fem,
                                                    color: Color(0x99000000),
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                // labelEkk (I159:8813;5904:28226)
                                                'Логин',
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 16*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.5*ffem/fem,
                                                  letterSpacing: 0.150000006*fem,
                                                  color: Color(0x99000000),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Text(
                                        // helpertextkj6 (I159:8813;5904:28228;6626:50981)
                                        'Helper text',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.6600000064*ffem/fem,
                                          letterSpacing: 0.400000006*fem,
                                          color: Color(0x99000000),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // textfieldtKW (159:8814)
                              left: 0*fem,
                              top: 53*fem,
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  width: 328*fem,
                                  height: 71*fem,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // inputzdS (I159:8814;5904:28224)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                                        width: double.infinity,
                                        height: 46*fem,
                                        child: Container(
                                          // autogroupxcyrYQ4 (2ggU7q67bLTEG7Q72gxCyr)
                                          padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                                          width: double.infinity,
                                          height: 45*fem,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // templabelrvY (I159:8814;5904:28225)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                child: Text(
                                                  'Label',
                                                  style: SafeGoogleFont (
                                                    'Roboto',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1*ffem/fem,
                                                    letterSpacing: 0.150000006*fem,
                                                    color: Color(0x99000000),
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                // labelARS (I159:8814;5904:28226)
                                                'Пароль',
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 16*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.5*ffem/fem,
                                                  letterSpacing: 0.150000006*fem,
                                                  color: Color(0x99000000),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Text(
                                        // helpertextJXe (I159:8814;5904:28228;6626:50981)
                                        'Helper text',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.6600000064*ffem/fem,
                                          letterSpacing: 0.400000006*fem,
                                          color: Color(0x99000000),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // button3EL (159:8815)
                      left: 0*fem,
                      top: 122*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(139*fem, 4*fem, 120*fem, 4*fem),
                          width: 328*fem,
                          height: 30*fem,
                          decoration: BoxDecoration (
                            color: Color(0xff2196f3),
                            borderRadius: BorderRadius.circular(4*fem),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x33000000),
                                offset: Offset(0*fem, 3*fem),
                                blurRadius: 0.5*fem,
                              ),
                              BoxShadow(
                                color: Color(0x23000000),
                                offset: Offset(0*fem, 2*fem),
                                blurRadius: 1*fem,
                              ),
                              BoxShadow(
                                color: Color(0x1e000000),
                                offset: Offset(0*fem, 1*fem),
                                blurRadius: 2.5*fem,
                              ),
                            ],
                          ),
                          child: Container(
                            // base2rx (I159:8815;5903:24522)
                            width: double.infinity,
                            height: double.infinity,
                            child: Container(
                              // autogroupjunuzYt (2ggUHaJso2S6gQzn3MJuNU)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                              padding: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                              width: 51*fem,
                              height: double.infinity,
                              child: Text(
                                'ВОЙТИ',
                                style: SafeGoogleFont (
                                  'Roboto',
                                  fontSize: 13*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.6923076923*ffem/fem,
                                  letterSpacing: 0.4600000083*fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // frame37358TBa (159:8816)
              left: 46.5*fem,
              top: 173*fem,
              child: Container(
                width: 268*fem,
                height: 122*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // subtract1NJY (159:8817)
                      left: 106.5*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 55*fem,
                          height: 55*fem,
                          child: Image.asset(
                            'assets/page-1/images/subtract-1.png',
                            width: 55*fem,
                            height: 55*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // frame37357G92 (159:8819)
                      left: 0*fem,
                      top: 70*fem,
                      child: Container(
                        width: 268*fem,
                        height: 52*fem,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // ticketokBWt (159:8820)
                              margin: EdgeInsets.fromLTRB(11*fem, 0*fem, 0*fem, 0*fem),
                              child: Text(
                                'Вход в Ticketok',
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 22*ffem,
                                  fontWeight: FontWeight.w700,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xff373737),
                                ),
                              ),
                            ),
                            Text(
                              // VGg (159:8821)
                              'Система сканирования билетов',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.3625*ffem/fem,
                                color: Color(0xff8a92a6),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // frame37359QPe (159:8822)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 268*fem,
                        height: 122*fem,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // subtract1wPa (159:8823)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15*fem),
                              width: 55*fem,
                              height: 55*fem,
                              child: Image.asset(
                                'assets/page-1/images/subtract-1-yuE.png',
                                width: 55*fem,
                                height: 55*fem,
                              ),
                            ),
                            Container(
                              // frame37357T72 (159:8825)
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // ticketokPmN (159:8826)
                                    margin: EdgeInsets.fromLTRB(11*fem, 0*fem, 0*fem, 0*fem),
                                    child: Text(
                                      'Вход в Ticketok',
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xff373737),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    // J7e (159:8827)
                                    'Система сканирования билетов',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Nunito',
                                      fontSize: 16*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3625*ffem/fem,
                                      color: Color(0xff8a92a6),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // rectangle5Cip (159:8895)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 360*fem,
                  height: 640*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xa5000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ihA (159:8874)
              left: 40*fem,
              top: 256*fem,
              child: Container(
                width: 280*fem,
                height: 129*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(4*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x33000000),
                      offset: Offset(0*fem, 8*fem),
                      blurRadius: 5*fem,
                    ),
                    BoxShadow(
                      color: Color(0x1e000000),
                      offset: Offset(0*fem, 6*fem),
                      blurRadius: 15*fem,
                    ),
                    BoxShadow(
                      color: Color(0x23000000),
                      offset: Offset(0*fem, 16*fem),
                      blurRadius: 12*fem,
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                    Positioned(
                      // selectMk8 (159:8875)
                      left: 24*fem,
                      top: 18*fem,
                      child: TextButton(
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          width: 232*fem,
                          height: 72.5*fem,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // input4uS (I159:8875;6570:40855)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7.5*fem),
                                padding: EdgeInsets.fromLTRB(12*fem, 0*fem, 12*fem, 8*fem),
                                width: double.infinity,
                                decoration: BoxDecoration (
                                  border: Border.all(color: Color(0x3a000000)),
                                  borderRadius: BorderRadius.circular(4*fem),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      // labelcontainerknG (I159:8875;6570:40856)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                      padding: EdgeInsets.fromLTRB(4*fem, 0*fem, 0*fem, 0*fem),
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                      ),
                                      child: Text(
                                        'Выберите мероприятие',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1*ffem/fem,
                                          letterSpacing: 0.150000006*fem,
                                          color: Color(0x99000000),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // containerq32 (I159:8875;6570:40858)
                                      width: double.infinity,
                                      height: 24*fem,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // autogrouph48tnDA (2ggUgyoYXyJvQRcxTFH48t)
                                            width: 184*fem,
                                            height: double.infinity,
                                            child: Container(
                                              // autogroup5mnt8np (2ggUreC7TCg7EKGoYN5MNt)
                                              width: 134*fem,
                                              height: double.infinity,
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    // chipUrg (I159:8875;11158:165057)
                                                    left: 0*fem,
                                                    top: 0*fem,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(4*fem, 3*fem, 4*fem, 0*fem),
                                                      width: 63*fem,
                                                      height: 24*fem,
                                                      decoration: BoxDecoration (
                                                        color: Color(0x14000000),
                                                        borderRadius: BorderRadius.circular(100*fem),
                                                      ),
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogroupt5znNhA (2ggUyUL4iq85tAnZEyt5Zn)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6*fem, 0*fem),
                                                            padding: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 0*fem),
                                                            height: 26*fem,
                                                            child: Text(
                                                              'Chip',
                                                              style: SafeGoogleFont (
                                                                'Roboto',
                                                                fontSize: 13*ffem,
                                                                fontWeight: FontWeight.w400,
                                                                height: 1.3846153846*ffem/fem,
                                                                letterSpacing: 0.1599999964*fem,
                                                                color: Color(0xdd000000),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            // cancelfilledqak (I159:8875;11158:165057;6588:47857)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3*fem),
                                                            width: 16*fem,
                                                            height: 16*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/cancelfilled.png',
                                                              width: 16*fem,
                                                              height: 16*fem,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    // valuewdn (I159:8875;6570:40860)
                                                    left: 0*fem,
                                                    top: 0*fem,
                                                    child: Align(
                                                      child: SizedBox(
                                                        width: 130*fem,
                                                        height: 24*fem,
                                                        child: Text(
                                                          'Viva Braslav 2023',
                                                          style: SafeGoogleFont (
                                                            'Roboto',
                                                            fontSize: 16*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            letterSpacing: 0.150000006*fem,
                                                            color: Color(0xdd000000),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // autogroupbpspEct (2ggW3cDCRA5LW9xwvtbpSp)
                                            width: 24*fem,
                                            height: 5*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/auto-group-bpsp.png',
                                              width: 24*fem,
                                              height: 5*fem,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Text(
                                // helpertextyKa (I159:8875;10067:123073;6626:50981)
                                'Helper text',
                                style: SafeGoogleFont (
                                  'Roboto',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.6600000064*ffem/fem,
                                  letterSpacing: 0.400000006*fem,
                                  color: Color(0x99000000),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // buttonsuj2 (159:8876)
                      left: 21.5*fem,
                      top: 83*fem,
                      child: Container(
                        width: 237*fem,
                        height: 36*fem,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // buttonqMn (159:8877)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                              width: 100*fem,
                              height: double.infinity,
                              decoration: BoxDecoration (
                                borderRadius: BorderRadius.circular(4*fem),
                              ),
                              child: Center(
                                child: Center(
                                  child: Text(
                                    'ОТМЕНИТЬ',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1428571429*ffem/fem,
                                      letterSpacing: 1.25*fem,
                                      color: Color(0xffbb6bd9),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              // button5mv (159:8878)
                              width: 129*fem,
                              height: double.infinity,
                              decoration: BoxDecoration (
                                borderRadius: BorderRadius.circular(4*fem),
                              ),
                              child: Center(
                                child: Center(
                                  child: Text(
                                    'ПОДТВЕРДИТЬ',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1428571429*ffem/fem,
                                      letterSpacing: 1.25*fem,
                                      color: Color(0xff6200ee),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}