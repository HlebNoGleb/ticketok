import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // 9AC (159:8896)
        width: double.infinity,
        height: 640*fem,
        decoration: BoxDecoration (
          color: Color(0xfffcfcfc),
        ),
        child: Stack(
          children: [
            Positioned(
              // toparegularaflat3Fa (159:8897)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 16*fem),
                width: 360*fem,
                height: 56*fem,
                decoration: BoxDecoration (
                  color: Color(0xff2196f3),
                ),
                child: Text(
                  'Профиль работника',
                  style: SafeGoogleFont (
                    'Roboto',
                    fontSize: 20*ffem,
                    fontWeight: FontWeight.w500,
                    height: 1.2*ffem/fem,
                    letterSpacing: 0.150000006*fem,
                    color: Color(0xffffffff),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame6FsS (159:8898)
              left: 16*fem,
              top: 182*fem,
              child: Container(
                width: 222*fem,
                height: 50*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // maskgroupNhA (159:8899)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                      width: 50*fem,
                      height: 50*fem,
                      child: Image.asset(
                        'assets/page-1/images/mask-group-4qJ.png',
                        width: 50*fem,
                        height: 50*fem,
                      ),
                    ),
                    Container(
                      // frame5VFz (159:8902)
                      margin: EdgeInsets.fromLTRB(0*fem, 7.5*fem, 0*fem, 7*fem),
                      width: 162*fem,
                      height: double.infinity,
                      child: Stack(
                        children: [
                          Positioned(
                            // subtitle1Dhn (159:8903)
                            left: 0*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 162*fem,
                                height: 19*fem,
                                child: Text(
                                  'Снежана Тихонова',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    letterSpacing: 0.150000006*fem,
                                    color: Color(0xdd000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // subtitle2uac (159:8904)
                            left: 0*fem,
                            top: 18.5*fem,
                            child: Align(
                              child: SizedBox(
                                width: 100*fem,
                                height: 17*fem,
                                child: Text(
                                  'Оператор №1',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    letterSpacing: 0.150000006*fem,
                                    color: Color(0x99000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // frame8QXN (159:8905)
              left: 16*fem,
              top: 247*fem,
              child: Container(
                width: 302*fem,
                height: 84*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // subtitle3jJk (159:8906)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                      child: Text(
                        'Разрешённые сектора',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.1725*ffem/fem,
                          letterSpacing: 0.150000006*fem,
                          color: Color(0x99000000),
                        ),
                      ),
                    ),
                    Container(
                      // frame7qsa (159:8907)
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // autogroupgqbsPPJ (2ggcqQu26kpsk7FWhTgqBS)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 10*fem),
                            width: double.infinity,
                            height: 24*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // chipucY (159:8908)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(10*fem, 3*fem, 0*fem, 3*fem),
                                      width: 111*fem,
                                      height: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0xff2196f3),
                                        borderRadius: BorderRadius.circular(100*fem),
                                      ),
                                      child: Container(
                                        // typographyCLk (I159:8908;6588:47879)
                                        width: double.infinity,
                                        height: double.infinity,
                                        child: Center(
                                          child: Text(
                                            'Кемпинг 4 дня',
                                            style: SafeGoogleFont (
                                              'Roboto',
                                              fontSize: 13*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.3846153846*ffem/fem,
                                              letterSpacing: 0.1599999964*fem,
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                TextButton(
                                  // chipUp4 (159:8909)
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(10*fem, 3*fem, 0*fem, 3*fem),
                                    width: 169*fem,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xff2196f3),
                                      borderRadius: BorderRadius.circular(100*fem),
                                    ),
                                    child: Container(
                                      // typographyPRE (I159:8909;6588:47879)
                                      width: 160*fem,
                                      height: double.infinity,
                                      child: Center(
                                        child: Text(
                                          'Глэмпинг Comfort 4 дня',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 13*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.3846153846*ffem/fem,
                                            letterSpacing: 0.1599999964*fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroup7sdvhRv (2ggd6EoecSLPMbWb2K7sdv)
                            width: double.infinity,
                            height: 24*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // chipr3v (159:8910)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(10*fem, 3*fem, 0*fem, 3*fem),
                                      width: 159*fem,
                                      height: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0xff2196f3),
                                        borderRadius: BorderRadius.circular(100*fem),
                                      ),
                                      child: Container(
                                        // typographyirp (I159:8910;6588:47879)
                                        width: 150*fem,
                                        height: double.infinity,
                                        child: Center(
                                          child: Text(
                                            'Глэмпинг Luxary 4 дня',
                                            style: SafeGoogleFont (
                                              'Roboto',
                                              fontSize: 13*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.3846153846*ffem/fem,
                                              letterSpacing: 0.1599999964*fem,
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                TextButton(
                                  // chipqRe (159:8911)
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(10*fem, 3*fem, 4*fem, 3*fem),
                                    width: 133*fem,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xff2196f3),
                                      borderRadius: BorderRadius.circular(100*fem),
                                    ),
                                    child: Container(
                                      // typographyM96 (I159:8911;6588:47879)
                                      width: double.infinity,
                                      height: double.infinity,
                                      child: Center(
                                        child: Text(
                                          'Авто Garage 4 дня',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 13*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.3846153846*ffem/fem,
                                            letterSpacing: 0.1599999964*fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // subtitle4TC8 (159:8912)
              left: 53*fem,
              top: 553*fem,
              child: Align(
                child: SizedBox(
                  width: 286*fem,
                  height: 15*fem,
                  child: Text(
                    'Чтобы начать работу, нажмите кнопку ниже',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.1725*ffem/fem,
                      letterSpacing: 0.150000006*fem,
                      color: Color(0x99000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // buttonXBz (159:8913)
              left: 16*fem,
              top: 582*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(98.5*fem, 8*fem, 99.5*fem, 8*fem),
                  width: 328*fem,
                  height: 42*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff2e7d32),
                    borderRadius: BorderRadius.circular(4*fem),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x33000000),
                        offset: Offset(0*fem, 3*fem),
                        blurRadius: 0.5*fem,
                      ),
                      BoxShadow(
                        color: Color(0x23000000),
                        offset: Offset(0*fem, 2*fem),
                        blurRadius: 1*fem,
                      ),
                      BoxShadow(
                        color: Color(0x1e000000),
                        offset: Offset(0*fem, 1*fem),
                        blurRadius: 2.5*fem,
                      ),
                    ],
                  ),
                  child: Container(
                    // baseMB2 (I159:8913;5903:24127)
                    padding: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 0*fem),
                    width: double.infinity,
                    height: double.infinity,
                    child: Text(
                      'НАЧАТЬ CМЕНУ',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.7333333333*ffem/fem,
                        letterSpacing: 0.4600000083*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // fixedatextq6C (159:8914)
              left: 0*fem,
              top: 56*fem,
              child: Container(
                width: 360*fem,
                height: 48*fem,
                decoration: BoxDecoration (
                  color: Color(0xff2196f3),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // tablstatesjhN (I159:8914;242:8097)
                      padding: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 0*fem),
                      width: 120*fem,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0xff2196f3),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // tabeJY (I159:8914;242:8097;242:8069)
                            margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 14*fem),
                            child: Text(
                              'ГЛАВНАЯ',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.1428571429*ffem/fem,
                                letterSpacing: 1.25*fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                          Container(
                            // indicatorwHe (I159:8914;242:8097;242:8068)
                            width: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xff2196f3),
                            ),
                            child: Center(
                              // indicatortya (I159:8914;242:8097;242:8068;242:8071)
                              child: SizedBox(
                                width: double.infinity,
                                height: 2*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // tablstatesdRN (I159:8914;242:8098)
                      width: 120*fem,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0xff2196f3),
                      ),
                      child: Center(
                        child: Text(
                          'ИНФО',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1428571429*ffem/fem,
                            letterSpacing: 1.25*fem,
                            color: Color(0xbcffffff),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // tablstatesKJC (I159:8914;242:8099)
                      width: 120*fem,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0xff2196f3),
                      ),
                      child: Center(
                        child: Text(
                          'НАСТРОЙКИ',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1428571429*ffem/fem,
                            letterSpacing: 1.25*fem,
                            color: Color(0xbcffffff),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // alertoDN (159:8915)
              left: 16*fem,
              top: 119*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(16*fem, 10*fem, 16*fem, 8*fem),
                width: 328*fem,
                height: 48*fem,
                decoration: BoxDecoration (
                  color: Color(0xffe5f6fd),
                  borderRadius: BorderRadius.circular(4*fem),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // iconcontainertEp (I159:8915;5903:35272)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 2*fem),
                      width: 22*fem,
                      height: 22*fem,
                      child: Image.asset(
                        'assets/page-1/images/icon-container.png',
                        width: 22*fem,
                        height: 22*fem,
                      ),
                    ),
                    Container(
                      // text14Y (I159:8915;5903:35274)
                      margin: EdgeInsets.fromLTRB(0*fem, 4*fem, 69*fem, 2*fem),
                      height: double.infinity,
                      child: Text(
                        'Viva Braslav 2023 ',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.4299998965*ffem/fem,
                          letterSpacing: 0.1700000018*fem,
                          color: Color(0xff014361),
                        ),
                      ),
                    ),
                    Container(
                      // onclosecontainerHGx (I159:8915;5903:35277)
                      width: 75*fem,
                      height: double.infinity,
                      child: TextButton(
                        // buttone7W (I159:8915;5903:35278)
                        onPressed: () {},
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 1*fem, 4*fem),
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(4*fem),
                          ),
                          child: Container(
                            // baseA5r (I159:8915;5903:35278;9996:110169)
                            padding: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                            width: double.infinity,
                            height: double.infinity,
                            child: Text(
                              'СМЕНИТЬ',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 13*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.6923076923*ffem/fem,
                                letterSpacing: 0.4600000083*fem,
                                color: Color(0xff014361),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // rectangle64h2 (159:8962)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 360*fem,
                  height: 640*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xa5000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // z4t (159:8963)
              left: 40*fem,
              top: 256*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(18*fem, 23*fem, 18*fem, 10*fem),
                width: 280*fem,
                height: 129*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(4*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x33000000),
                      offset: Offset(0*fem, 8*fem),
                      blurRadius: 5*fem,
                    ),
                    BoxShadow(
                      color: Color(0x1e000000),
                      offset: Offset(0*fem, 6*fem),
                      blurRadius: 15*fem,
                    ),
                    BoxShadow(
                      color: Color(0x23000000),
                      offset: Offset(0*fem, 16*fem),
                      blurRadius: 12*fem,
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // dialogcontentBQG (159:8964)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15.5*fem, 20*fem),
                      padding: EdgeInsets.fromLTRB(15.5*fem, 0*fem, 0*fem, 0*fem),
                      child: Align(
                        // bodyVvk (159:8966)
                        alignment: Alignment.centerRight,
                        child: SizedBox(
                          child: Container(
                            constraints: BoxConstraints (
                              maxWidth: 201*fem,
                            ),
                            child: Text(
                              'Вы действительно хотите \nначать смену?',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.4285714286*ffem/fem,
                                letterSpacing: 0.25*fem,
                                color: Color(0x99000000),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // buttonsNje (159:8967)
                      width: double.infinity,
                      height: 36*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // buttonj4Q (159:8968)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                            width: 100*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(4*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'ОТМЕНИТЬ',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: 1.25*fem,
                                    color: Color(0xffbb6bd9),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // buttonAfW (159:8969)
                            width: 136*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(4*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'НАЧАТЬ СМЕНУ',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1428571429*ffem/fem,
                                    letterSpacing: 1.25*fem,
                                    color: Color(0xff6200ee),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}