import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 280;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // 3ZN (99:9479)
        width: double.infinity,
        height: 129*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          borderRadius: BorderRadius.circular(4*fem),
          boxShadow: [
            BoxShadow(
              color: Color(0x33000000),
              offset: Offset(0*fem, 8*fem),
              blurRadius: 5*fem,
            ),
            BoxShadow(
              color: Color(0x1e000000),
              offset: Offset(0*fem, 6*fem),
              blurRadius: 15*fem,
            ),
            BoxShadow(
              color: Color(0x23000000),
              offset: Offset(0*fem, 16*fem),
              blurRadius: 12*fem,
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              // select7JL (99:3461)
              left: 24*fem,
              top: 18*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 232*fem,
                  height: 72.5*fem,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        // inputRpp (I99:3461;6570:40855)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7.5*fem),
                        padding: EdgeInsets.fromLTRB(12*fem, 0*fem, 12*fem, 8*fem),
                        width: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0x3a000000)),
                          borderRadius: BorderRadius.circular(4*fem),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              // labelcontainer7xY (I99:3461;6570:40856)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                              padding: EdgeInsets.fromLTRB(4*fem, 0*fem, 0*fem, 0*fem),
                              decoration: BoxDecoration (
                                color: Color(0xffffffff),
                              ),
                              child: Text(
                                'Выберите мероприятие',
                                style: SafeGoogleFont (
                                  'Roboto',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1*ffem/fem,
                                  letterSpacing: 0.150000006*fem,
                                  color: Color(0x99000000),
                                ),
                              ),
                            ),
                            Container(
                              // containerNNg (I99:3461;6570:40858)
                              width: double.infinity,
                              height: 24*fem,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // autogroupxvrpK32 (2ggtF44Ki7VxXaAUSFxvrp)
                                    width: 184*fem,
                                    height: double.infinity,
                                    child: Container(
                                      // autogroupme6pfMn (2ggtQiStdLs9MTpKXNmE6p)
                                      width: 134*fem,
                                      height: double.infinity,
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // chipoyn (I99:3461;11158:165057)
                                            left: 0*fem,
                                            top: 0*fem,
                                            child: Container(
                                              padding: EdgeInsets.fromLTRB(4*fem, 3*fem, 4*fem, 0*fem),
                                              width: 63*fem,
                                              height: 24*fem,
                                              decoration: BoxDecoration (
                                                color: Color(0x14000000),
                                                borderRadius: BorderRadius.circular(100*fem),
                                              ),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // autogroupdzpz5gQ (2ggtX3bgCDd2Sqf7gjDZPz)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6*fem, 0*fem),
                                                    padding: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 0*fem),
                                                    height: 26*fem,
                                                    child: Text(
                                                      'Chip',
                                                      style: SafeGoogleFont (
                                                        'Roboto',
                                                        fontSize: 13*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.3846153846*ffem/fem,
                                                        letterSpacing: 0.1599999964*fem,
                                                        color: Color(0xdd000000),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    // cancelfilledjkx (I99:3461;11158:165057;6588:47857)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3*fem),
                                                    width: 16*fem,
                                                    height: 16*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/cancelfilled-25S.png',
                                                      width: 16*fem,
                                                      height: 16*fem,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // valueFjJ (I99:3461;6570:40860)
                                            left: 0*fem,
                                            top: 0*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 130*fem,
                                                height: 24*fem,
                                                child: Text(
                                                  'Viva Braslav 2023',
                                                  style: SafeGoogleFont (
                                                    'Roboto',
                                                    fontSize: 16*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.5*ffem/fem,
                                                    letterSpacing: 0.150000006*fem,
                                                    color: Color(0xdd000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // autogroupqvtzkRA (2ggubr8NADVjp8Q7kzQVTz)
                                    width: 24*fem,
                                    height: 5*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/auto-group-qvtz.png',
                                      width: 24*fem,
                                      height: 5*fem,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Text(
                        // helpertextfo2 (I99:3461;10067:123073;6626:50981)
                        'Helper text',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 12*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.6600000064*ffem/fem,
                          letterSpacing: 0.400000006*fem,
                          color: Color(0x99000000),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              // buttonsPyv (99:9483)
              left: 21.5*fem,
              top: 83*fem,
              child: Container(
                width: 237*fem,
                height: 36*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // buttonX4Y (99:9484)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                      width: 100*fem,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(4*fem),
                      ),
                      child: Center(
                        child: Center(
                          child: Text(
                            'ОТМЕНИТЬ',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              letterSpacing: 1.25*fem,
                              color: Color(0xffbb6bd9),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // buttonmzU (99:9485)
                      width: 129*fem,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(4*fem),
                      ),
                      child: Center(
                        child: Center(
                          child: Text(
                            'ПОДТВЕРДИТЬ',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              letterSpacing: 1.25*fem,
                              color: Color(0xff6200ee),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}