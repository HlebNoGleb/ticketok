import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 640;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // telegramcloudphotosize25474171 (47:1722)
        width: double.infinity,
        height: 337.5*fem,
        child: Image.asset(
          'assets/page-1/images/telegram-cloud-photo-size-2-5474171831956127571-y-1.png',
          fit: BoxFit.cover,
        ),
      ),
          );
  }
}