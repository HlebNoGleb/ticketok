import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // loaderag4 (1:23747)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffcfcfc),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // toparegularaflatJMA (1:23748)
              padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 16*fem),
              width: double.infinity,
              height: 56*fem,
              decoration: BoxDecoration (
                color: Color(0xff2196f3),
              ),
              child: Container(
                // autogroupkvpep4c (2ggrdmQRtATQ1BT4UrKvPe)
                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 129*fem, 0*fem),
                width: 199*fem,
                height: double.infinity,
                child: Center(
                  child: Text(
                    'Работа с билетами',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.2*ffem/fem,
                      letterSpacing: 0.150000006*fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupk4msU9A (2ggrQrcGu36b3BvzPWk4MS)
              padding: EdgeInsets.fromLTRB(85*fem, 240*fem, 85*fem, 239*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // frame9CL4 (1:23753)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 25*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // h5jKz (1:23754)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                          child: Text(
                            'Подождите...',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              letterSpacing: 0.1800000072*fem,
                              color: Color(0xdd000000),
                            ),
                          ),
                        ),
                        Text(
                          // subtitle12pt (1:23755)
                          'Выполняется запрос...',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.150000006*fem,
                            color: Color(0xdd000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // progresscircularxCk (1:23773)
                    margin: EdgeInsets.fromLTRB(71.5*fem, 0*fem, 79*fem, 0*fem),
                    width: double.infinity,
                    height: 32*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // ringGUL (I1:23773;10120:128914)
                          left: 7.5*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 32*fem,
                              height: 32*fem,
                              child: Image.asset(
                                'assets/page-1/images/ring.png',
                                width: 32*fem,
                                height: 32*fem,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // minwidthAJp (I1:23773;11398:157668)
                          left: 7.5*fem,
                          top: 0*fem,
                          child: Container(
                            width: 32*fem,
                            height: 32*fem,
                          ),
                        ),
                        Positioned(
                          // body1JA8 (I1:23773;6586:47020;6605:52865)
                          left: 0*fem,
                          top: 6*fem,
                          child: Align(
                            child: SizedBox(
                              width: 24*fem,
                              height: 20*fem,
                              child: Text(
                                '99%',
                                style: SafeGoogleFont (
                                  'Roboto',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.6600000064*ffem/fem,
                                  letterSpacing: 0.400000006*fem,
                                  color: Color(0x99000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}