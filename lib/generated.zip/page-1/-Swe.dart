import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // rAg (208:11933)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffcfcfc),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // toparegularaflatZKz (208:11934)
              padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 16*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xff2196f3),
              ),
              child: Text(
                'Профиль работника',
                style: SafeGoogleFont (
                  'Roboto',
                  fontSize: 20*ffem,
                  fontWeight: FontWeight.w500,
                  height: 1.2*ffem/fem,
                  letterSpacing: 0.150000006*fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // fixedatext1Bz (208:11951)
              width: double.infinity,
              height: 48*fem,
              decoration: BoxDecoration (
                color: Color(0xff2196f3),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // tablstatesXg8 (I208:11951;242:8097)
                    padding: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 0*fem),
                    width: 120*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xff2196f3),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // tabdUG (I208:11951;242:8097;242:8069)
                          margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 14*fem),
                          child: Text(
                            'ГЛАВНАЯ',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              letterSpacing: 1.25*fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                        Container(
                          // indicatorWY4 (I208:11951;242:8097;242:8068)
                          width: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff2196f3),
                          ),
                          child: Center(
                            // indicatorffr (I208:11951;242:8097;242:8068;242:8071)
                            child: SizedBox(
                              width: double.infinity,
                              height: 2*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // tablstatesQNY (I208:11951;242:8098)
                    width: 120*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xff2196f3),
                    ),
                    child: Center(
                      child: Text(
                        'ИНФО',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.1428571429*ffem/fem,
                          letterSpacing: 1.25*fem,
                          color: Color(0xbcffffff),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // tablstates5Dn (I208:11951;242:8099)
                    width: 120*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xff2196f3),
                    ),
                    child: Center(
                      child: Text(
                        'НАСТРОЙКИ',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.1428571429*ffem/fem,
                          letterSpacing: 1.25*fem,
                          color: Color(0xbcffffff),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupnvywwWt (2ggZUqpZCogDjh5NAQnVyW)
              padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 16*fem, 16*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // alertTk8 (208:11952)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15*fem),
                    padding: EdgeInsets.fromLTRB(16*fem, 10*fem, 24*fem, 8*fem),
                    width: double.infinity,
                    height: 48*fem,
                    decoration: BoxDecoration (
                      color: Color(0xfffff4e5),
                      borderRadius: BorderRadius.circular(4*fem),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // iconcontainer9sr (I208:11952;5903:35262)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 2*fem),
                          width: 22*fem,
                          height: 22*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-container-NAY.png',
                            width: 22*fem,
                            height: 22*fem,
                          ),
                        ),
                        Container(
                          // texts3A (I208:11952;5903:35264)
                          margin: EdgeInsets.fromLTRB(0*fem, 4*fem, 30*fem, 2*fem),
                          height: double.infinity,
                          child: Text(
                            'Viva Braslav 2023 (Offline)',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.4299998965*ffem/fem,
                              letterSpacing: 0.1700000018*fem,
                              color: Color(0xff663c00),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupkjwi9Fa (2ggb33jFXmxXJopCxgkjwi)
                          width: 54*fem,
                          height: double.infinity,
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // frame6J8U (208:11935)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 106*fem, 15*fem),
                    width: double.infinity,
                    height: 50*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // maskgroupRit (208:11936)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                          width: 50*fem,
                          height: 50*fem,
                          child: Image.asset(
                            'assets/page-1/images/mask-group-7xp.png',
                            width: 50*fem,
                            height: 50*fem,
                          ),
                        ),
                        Container(
                          // frame5jUg (208:11939)
                          margin: EdgeInsets.fromLTRB(0*fem, 7.5*fem, 0*fem, 7*fem),
                          width: 162*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // subtitle14Wx (208:11940)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 162*fem,
                                    height: 19*fem,
                                    child: Text(
                                      'Снежана Тихонова',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        letterSpacing: 0.150000006*fem,
                                        color: Color(0xdd000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // subtitle2LzG (208:11941)
                                left: 0*fem,
                                top: 18.5*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 100*fem,
                                    height: 17*fem,
                                    child: Text(
                                      'Оператор №1',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        letterSpacing: 0.150000006*fem,
                                        color: Color(0x99000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // frame8EZr (208:11942)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 26*fem, 222*fem),
                    width: 302*fem,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // subtitle3AyJ (208:11943)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                          child: Text(
                            'Разрешённые сектора',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              letterSpacing: 0.150000006*fem,
                              color: Color(0x99000000),
                            ),
                          ),
                        ),
                        Container(
                          // frame7gwe (208:11944)
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // autogroupbxfjr5S (2ggZkvC6yNQyFNWqLRbXfJ)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 10*fem),
                                width: double.infinity,
                                height: 24*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // chipB7i (208:11945)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                      child: TextButton(
                                        onPressed: () {},
                                        style: TextButton.styleFrom (
                                          padding: EdgeInsets.zero,
                                        ),
                                        child: Container(
                                          padding: EdgeInsets.fromLTRB(10*fem, 3*fem, 0*fem, 3*fem),
                                          width: 111*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xff2196f3),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: Container(
                                            // typographyTb2 (I208:11945;6588:47879)
                                            width: double.infinity,
                                            height: double.infinity,
                                            child: Center(
                                              child: Text(
                                                'Кемпинг 4 дня',
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 13*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.3846153846*ffem/fem,
                                                  letterSpacing: 0.1599999964*fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    TextButton(
                                      // chip9ye (208:11946)
                                      onPressed: () {},
                                      style: TextButton.styleFrom (
                                        padding: EdgeInsets.zero,
                                      ),
                                      child: Container(
                                        padding: EdgeInsets.fromLTRB(10*fem, 3*fem, 0*fem, 3*fem),
                                        width: 169*fem,
                                        height: double.infinity,
                                        decoration: BoxDecoration (
                                          color: Color(0xff2196f3),
                                          borderRadius: BorderRadius.circular(100*fem),
                                        ),
                                        child: Container(
                                          // typographyfBJ (I208:11946;6588:47879)
                                          width: 160*fem,
                                          height: double.infinity,
                                          child: Center(
                                            child: Text(
                                              'Глэмпинг Comfort 4 дня',
                                              style: SafeGoogleFont (
                                                'Roboto',
                                                fontSize: 13*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.3846153846*ffem/fem,
                                                letterSpacing: 0.1599999964*fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // autogroupnyxjM48 (2gga1QmxMDTkVCzby6nyXJ)
                                width: double.infinity,
                                height: 24*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // chipVRE (208:11947)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
                                      child: TextButton(
                                        onPressed: () {},
                                        style: TextButton.styleFrom (
                                          padding: EdgeInsets.zero,
                                        ),
                                        child: Container(
                                          padding: EdgeInsets.fromLTRB(10*fem, 3*fem, 0*fem, 3*fem),
                                          width: 159*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xff2196f3),
                                            borderRadius: BorderRadius.circular(100*fem),
                                          ),
                                          child: Container(
                                            // typographyyLQ (I208:11947;6588:47879)
                                            width: 150*fem,
                                            height: double.infinity,
                                            child: Center(
                                              child: Text(
                                                'Глэмпинг Luxary 4 дня',
                                                style: SafeGoogleFont (
                                                  'Roboto',
                                                  fontSize: 13*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.3846153846*ffem/fem,
                                                  letterSpacing: 0.1599999964*fem,
                                                  color: Color(0xffffffff),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    TextButton(
                                      // chipfj2 (208:11948)
                                      onPressed: () {},
                                      style: TextButton.styleFrom (
                                        padding: EdgeInsets.zero,
                                      ),
                                      child: Container(
                                        padding: EdgeInsets.fromLTRB(10*fem, 3*fem, 4*fem, 3*fem),
                                        width: 133*fem,
                                        height: double.infinity,
                                        decoration: BoxDecoration (
                                          color: Color(0xff2196f3),
                                          borderRadius: BorderRadius.circular(100*fem),
                                        ),
                                        child: Container(
                                          // typographyNdS (I208:11948;6588:47879)
                                          width: double.infinity,
                                          height: double.infinity,
                                          child: Center(
                                            child: Text(
                                              'Авто Garage 4 дня',
                                              style: SafeGoogleFont (
                                                'Roboto',
                                                fontSize: 13*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.3846153846*ffem/fem,
                                                letterSpacing: 0.1599999964*fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // subtitle4g8L (208:11949)
                    margin: EdgeInsets.fromLTRB(32*fem, 0*fem, 0*fem, 14*fem),
                    child: Text(
                      'Чтобы начать работу, нажмите кнопку ниже',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 12*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.1725*ffem/fem,
                        letterSpacing: 0.150000006*fem,
                        color: Color(0x99000000),
                      ),
                    ),
                  ),
                  TextButton(
                    // buttonCMa (208:11950)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      padding: EdgeInsets.fromLTRB(98.5*fem, 8*fem, 99.5*fem, 8*fem),
                      width: double.infinity,
                      height: 42*fem,
                      decoration: BoxDecoration (
                        color: Color(0xff2e7d32),
                        borderRadius: BorderRadius.circular(4*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x33000000),
                            offset: Offset(0*fem, 3*fem),
                            blurRadius: 0.5*fem,
                          ),
                          BoxShadow(
                            color: Color(0x23000000),
                            offset: Offset(0*fem, 2*fem),
                            blurRadius: 1*fem,
                          ),
                          BoxShadow(
                            color: Color(0x1e000000),
                            offset: Offset(0*fem, 1*fem),
                            blurRadius: 2.5*fem,
                          ),
                        ],
                      ),
                      child: Container(
                        // base3d6 (I208:11950;5903:24127)
                        padding: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 0*fem),
                        width: double.infinity,
                        height: double.infinity,
                        child: Text(
                          'НАЧАТЬ CМЕНУ',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.7333333333*ffem/fem,
                            letterSpacing: 0.4600000083*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}