import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 599;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // aip (159:8799)
        width: double.infinity,
        height: 71*fem,
        child: Text(
          'Тестовые билеты',
          style: SafeGoogleFont (
            'Roboto',
            fontSize: 60*ffem,
            fontWeight: FontWeight.w800,
            height: 1.1725*ffem/fem,
            color: Color(0xffffffff),
          ),
        ),
      ),
          );
  }
}