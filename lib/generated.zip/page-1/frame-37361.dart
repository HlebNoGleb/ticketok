import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 1310;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // frame37361c9i (159:8809)
        width: double.infinity,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // mobileticket3xUU (159:8805)
              width: 320*fem,
              height: 565*fem,
              child: Image.asset(
                'assets/page-1/images/mobile-ticket-3.png',
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(
              width: 10*fem,
            ),
            Container(
              // mobileticket11Uxc (159:8808)
              width: 320*fem,
              height: 565*fem,
              child: Image.asset(
                'assets/page-1/images/mobile-ticket-1-1.png',
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(
              width: 10*fem,
            ),
            Container(
              // mobileticket21Q5a (159:8807)
              width: 320*fem,
              height: 565*fem,
              child: Image.asset(
                'assets/page-1/images/mobile-ticket-2-1.png',
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(
              width: 10*fem,
            ),
            Container(
              // mobileticket31XAC (159:8806)
              width: 320*fem,
              height: 565*fem,
              child: Image.asset(
                'assets/page-1/images/mobile-ticket-3-1.png',
                fit: BoxFit.cover,
              ),
            ),
          ],
        ),
      ),
          );
  }
}