import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // UMi (1:22851)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffcfcfc),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // toparegularaflatntC (1:23705)
              padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 16*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xff2196f3),
              ),
              child: Text(
                'Профиль работника',
                style: SafeGoogleFont (
                  'Roboto',
                  fontSize: 20*ffem,
                  fontWeight: FontWeight.w500,
                  height: 1.2*ffem/fem,
                  letterSpacing: 0.150000006*fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // fixedatextFmn (1:22855)
              width: double.infinity,
              height: 48*fem,
              decoration: BoxDecoration (
                color: Color(0xff2196f3),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // tablstatesP7J (1:22856)
                    width: 120*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xff2196f3),
                    ),
                    child: Center(
                      child: Text(
                        'ГЛАВНАЯ',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.1428571429*ffem/fem,
                          letterSpacing: 1.25*fem,
                          color: Color(0xbcffffff),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // tablstatesf4p (1:22858)
                    width: 120*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xff2196f3),
                    ),
                    child: Center(
                      child: Text(
                        'ИНФО',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.1428571429*ffem/fem,
                          letterSpacing: 1.25*fem,
                          color: Color(0xbcffffff),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // tablstates9Vn (1:22857)
                    padding: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 0*fem),
                    width: 120*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xff2196f3),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // tabTmN (I1:22857;242:8069)
                          margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 14*fem),
                          child: Text(
                            'НАСТРОЙКИ',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              letterSpacing: 1.25*fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                        Container(
                          // indicatorxy2 (I1:22857;242:8068)
                          width: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff2196f3),
                          ),
                          child: Center(
                            // indicatorXFS (I1:22857;242:8068;242:8071)
                            child: SizedBox(
                              width: double.infinity,
                              height: 2*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupkldj4FN (2gghDHc13S1aCUTxXvKLDJ)
              padding: EdgeInsets.fromLTRB(16*fem, 45*fem, 16*fem, 16*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // frame37363ydE (208:12024)
                    margin: EdgeInsets.fromLTRB(29.5*fem, 0*fem, 30.5*fem, 86*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // frame37360JfW (103:9024)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14*fem),
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // subtract1Smi (103:9025)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15*fem),
                                width: 55*fem,
                                height: 55*fem,
                                child: Image.asset(
                                  'assets/page-1/images/subtract-1-UhS.png',
                                  width: 55*fem,
                                  height: 55*fem,
                                ),
                              ),
                              Container(
                                // frame37357kXW (103:9027)
                                width: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Text(
                                      // ticketok6bN (103:9028)
                                      'Ticketok',
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xff373737),
                                      ),
                                    ),
                                    Text(
                                      // pGU (103:9029)
                                      'Система сканирования билетов',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xff8a92a6),
                                      ),
                                    ),
                                    Text(
                                      // YCU (103:9031)
                                      'Версия 1.0',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xb28a92a6),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          // 5TJ (103:9032)
                          'Частное предприятие «Левол Групп»',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.3625*ffem/fem,
                            color: Color(0xff8a92a6),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // frame37364bgY (208:12025)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 100*fem),
                    width: 324*fem,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // frame37362L8L (208:8887)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 22*fem),
                          width: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // se4 (208:8883)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 168*fem, 0*fem),
                                child: Text(
                                  'Оффлайн-режим',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.4299998965*ffem/fem,
                                    letterSpacing: 0.1700000018*fem,
                                    color: Color(0x99000000),
                                  ),
                                ),
                              ),
                              Container(
                                // switchaHa (208:8877)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                width: 29*fem,
                                height: 16*fem,
                                child: Image.asset(
                                  'assets/page-1/images/switch.png',
                                  width: 29*fem,
                                  height: 16*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // buttontZA (208:11202)
                          margin: EdgeInsets.fromLTRB(55*fem, 0*fem, 52*fem, 0*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 0*fem, 4*fem),
                              width: double.infinity,
                              height: 30*fem,
                              decoration: BoxDecoration (
                                borderRadius: BorderRadius.circular(4*fem),
                              ),
                              child: Container(
                                // basey4p (I208:11202;5903:26064)
                                padding: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                                width: 220*fem,
                                height: double.infinity,
                                child: Text(
                                  'СИНХРОНИЗИРОВАТЬ ДАННЫЕ',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 13*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.6923076923*ffem/fem,
                                    letterSpacing: 0.4600000083*fem,
                                    color: Color(0xff2196f3),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // line150eAx (102:13991)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15*fem),
                    width: double.infinity,
                    height: 1*fem,
                    decoration: BoxDecoration (
                      color: Color(0xff929292),
                    ),
                  ),
                  Container(
                    // buttonmmN (101:9692)
                    margin: EdgeInsets.fromLTRB(87*fem, 0*fem, 87*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 0*fem, 4*fem),
                        width: double.infinity,
                        height: 30*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(4*fem),
                        ),
                        child: Container(
                          // baser28 (I101:9692;5903:26183)
                          padding: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                          width: 153*fem,
                          height: double.infinity,
                          child: Text(
                            'ВЫЙТИ ИЗ АККАУНТА',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 13*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.6923076923*ffem/fem,
                              letterSpacing: 0.4600000083*fem,
                              color: Color(0xffd32f2f),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}