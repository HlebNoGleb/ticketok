import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // aW8 (1:22782)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffcfcfc),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // toparegularaflat6Da (1:23723)
              padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 16*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xff2196f3),
              ),
              child: Text(
                'Профиль работника',
                style: SafeGoogleFont (
                  'Roboto',
                  fontSize: 20*ffem,
                  fontWeight: FontWeight.w500,
                  height: 1.2*ffem/fem,
                  letterSpacing: 0.150000006*fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // fixedatext8vx (1:22840)
              width: double.infinity,
              height: 48*fem,
              decoration: BoxDecoration (
                color: Color(0xff2196f3),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // tablstatesGGU (1:22842)
                    width: 120*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xff2196f3),
                    ),
                    child: Center(
                      child: Text(
                        'ГЛАВНАЯ',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.1428571429*ffem/fem,
                          letterSpacing: 1.25*fem,
                          color: Color(0xbcffffff),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // tablstatesiuA (1:22841)
                    padding: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 0*fem),
                    width: 120*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xff2196f3),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // tabdFS (I1:22841;242:8069)
                          margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 14*fem),
                          child: Text(
                            'ИНФО',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1428571429*ffem/fem,
                              letterSpacing: 1.25*fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                        Container(
                          // indicator8hz (I1:22841;242:8068)
                          width: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xff2196f3),
                          ),
                          child: Center(
                            // indicator6Pv (I1:22841;242:8068;242:8071)
                            child: SizedBox(
                              width: double.infinity,
                              height: 2*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // tablstatesDjS (1:22843)
                    width: 120*fem,
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xff2196f3),
                    ),
                    child: Center(
                      child: Text(
                        'НАСТРОЙКИ',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.1428571429*ffem/fem,
                          letterSpacing: 1.25*fem,
                          color: Color(0xbcffffff),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupuqbvhec (2ggeWN7UQtwUNfZHGouQBv)
              padding: EdgeInsets.fromLTRB(16*fem, 15*fem, 16*fem, 16*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // alertDsr (103:8975)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15*fem),
                    padding: EdgeInsets.fromLTRB(16*fem, 10*fem, 24*fem, 8*fem),
                    width: double.infinity,
                    height: 48*fem,
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0xff0288d1)),
                      borderRadius: BorderRadius.circular(4*fem),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // iconcontainerWMA (103:8976)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 2*fem),
                          width: 22*fem,
                          height: 22*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-container-WNp.png',
                            width: 22*fem,
                            height: 22*fem,
                          ),
                        ),
                        Container(
                          // autogroupvs5wcf6 (2ggejC5S7ZgbkF8XSbvs5W)
                          padding: EdgeInsets.fromLTRB(0*fem, 4*fem, 0*fem, 2*fem),
                          width: 254*fem,
                          height: double.infinity,
                          child: Container(
                            // textKpQ (103:8978)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 47*fem, 0*fem),
                            width: 207*fem,
                            height: double.infinity,
                            child: Text(
                              '3 часа 56 минут 12 секунд',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.4299998965*ffem/fem,
                                letterSpacing: 0.1700000018*fem,
                                color: Color(0xff014361),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // inputAKE (I159:8972;5904:28130)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14*fem),
                    padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6.5*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // labelf16 (I159:8972;5904:28131)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5.5*fem),
                          child: Text(
                            'График работы',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              letterSpacing: 0.150000006*fem,
                              color: Color(0x60000000),
                            ),
                          ),
                        ),
                        Container(
                          // contentm48 (I159:8972;5904:28132)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5.5*fem),
                          width: double.infinity,
                          height: 120*fem,
                          child: Container(
                            // autogrouphmb2hCg (2ggftVUdQLnB9pv9NFHMB2)
                            width: 275*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // valueSAG (I159:8972;5904:28136)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 275*fem,
                                      height: 120*fem,
                                      child: Text(
                                        '28.07.2023 06:00 - 28.07.2023 - 08:00\n28.07.2023 10:00 - 28.07.2023 - 12:00\n28.07.2023 14:00 - 28.07.2023 - 16:00\n28.07.2023 18:00 - 28.07.2023 - 20:00\n28.07.2023 22:00 - 29.07.2023 - 00:00',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 16*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.5*ffem/fem,
                                          letterSpacing: 0.150000006*fem,
                                          color: Color(0x60000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // helpertextWfv (I159:8972;5904:28142;11140:154887)
                                  left: 0*fem,
                                  top: 37*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 63*fem,
                                      height: 20*fem,
                                      child: Text(
                                        'Helper text',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.6600000064*ffem/fem,
                                          letterSpacing: 0.400000006*fem,
                                          color: Color(0x60000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // input2Xn (I103:8992;5904:28130)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 69*fem),
                    padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6.5*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // labelwue (I103:8992;5904:28131)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5.5*fem),
                          child: Text(
                            'Информация о билетах',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              letterSpacing: 0.150000006*fem,
                              color: Color(0x60000000),
                            ),
                          ),
                        ),
                        Container(
                          // contentGS8 (I103:8992;5904:28132)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5.5*fem),
                          width: double.infinity,
                          height: 120*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroup1fkgQYL (2ggfPfyKDZuyryrFwz1FkG)
                                width: 196*fem,
                                height: double.infinity,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // valuex44 (I103:8992;5904:28136)
                                      left: 0*fem,
                                      top: 0*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 158*fem,
                                          height: 120*fem,
                                          child: Text(
                                            'Всего: 11211\nВалидных: 11200\nНеразрешенных: 5\nПодделанных: 1\nПовторный вход: 5',
                                            style: SafeGoogleFont (
                                              'Roboto',
                                              fontSize: 16*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.5*ffem/fem,
                                              letterSpacing: 0.150000006*fem,
                                              color: Color(0x60000000),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // helpertext35W (I103:8992;5904:28142;11140:154887)
                                      left: 0*fem,
                                      top: 37*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 63*fem,
                                          height: 20*fem,
                                          child: Text(
                                            'Helper text',
                                            style: SafeGoogleFont (
                                              'Roboto',
                                              fontSize: 12*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.6600000064*ffem/fem,
                                              letterSpacing: 0.400000006*fem,
                                              color: Color(0x60000000),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // autogroupbyauWzg (2ggfXkaBk5bCR2YQVmByAU)
                                width: 132*fem,
                                height: 120*fem,
                                child: Image.asset(
                                  'assets/page-1/images/auto-group-byau.png',
                                  width: 132*fem,
                                  height: 120*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // subtitle5FSU (103:9004)
                    margin: EdgeInsets.fromLTRB(32*fem, 0*fem, 0*fem, 14*fem),
                    child: Text(
                      'Чтобы начать работу, нажмите кнопку ниже',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 12*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.1725*ffem/fem,
                        letterSpacing: 0.150000006*fem,
                        color: Color(0x99000000),
                      ),
                    ),
                  ),
                  TextButton(
                    // buttonwq6 (103:9005)
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      padding: EdgeInsets.fromLTRB(98.5*fem, 8*fem, 99.5*fem, 8*fem),
                      width: double.infinity,
                      height: 42*fem,
                      decoration: BoxDecoration (
                        color: Color(0xff2e7d32),
                        borderRadius: BorderRadius.circular(4*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x33000000),
                            offset: Offset(0*fem, 3*fem),
                            blurRadius: 0.5*fem,
                          ),
                          BoxShadow(
                            color: Color(0x23000000),
                            offset: Offset(0*fem, 2*fem),
                            blurRadius: 1*fem,
                          ),
                          BoxShadow(
                            color: Color(0x1e000000),
                            offset: Offset(0*fem, 1*fem),
                            blurRadius: 2.5*fem,
                          ),
                        ],
                      ),
                      child: Container(
                        // basenKv (I103:9005;5903:24127)
                        padding: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 0*fem),
                        width: double.infinity,
                        height: double.infinity,
                        child: Text(
                          'НАЧАТЬ CМЕНУ',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.7333333333*ffem/fem,
                            letterSpacing: 0.4600000083*fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}