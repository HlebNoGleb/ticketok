import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // typereentry81a (1:23902)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffcfcfc),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // toparegularaflat1r4 (1:23903)
              padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 16*fem),
              width: double.infinity,
              height: 56*fem,
              decoration: BoxDecoration (
                color: Color(0xff2196f3),
              ),
              child: Container(
                // autogroup45rtvTE (2ggqinvhQKBEecFZLo45rt)
                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 129*fem, 0*fem),
                width: 199*fem,
                height: double.infinity,
                child: Center(
                  child: Text(
                    'Работа с билетами',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.2*ffem/fem,
                      letterSpacing: 0.150000006*fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupaezsxep (2ggpq4utBM8KCEET3uAEZS)
              padding: EdgeInsets.fromLTRB(16*fem, 10*fem, 16*fem, 25*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // buttonG9i (1:23907)
                    margin: EdgeInsets.fromLTRB(77.5*fem, 0*fem, 76.5*fem, 97*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(5*fem, 8*fem, 3*fem, 8*fem),
                        width: double.infinity,
                        height: 42*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(4*fem),
                        ),
                        child: Container(
                          // baseLfN (I1:23907;5903:25926)
                          padding: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 0*fem),
                          width: double.infinity,
                          height: double.infinity,
                          child: Text(
                            'ЗАВЕРШИТЬ СМЕНУ',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.7333333333*ffem/fem,
                              letterSpacing: 0.4600000083*fem,
                              color: Color(0xffd32f2f),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // heroiconsoutlineswitchvertical (1:23908)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 25*fem),
                    width: 70*fem,
                    height: 70*fem,
                    child: Image.asset(
                      'assets/page-1/images/heroicons-outline-switch-vertical-Cc4.png',
                      width: 70*fem,
                      height: 70*fem,
                    ),
                  ),
                  Container(
                    // frame985S (1:23904)
                    margin: EdgeInsets.fromLTRB(14*fem, 0*fem, 15*fem, 28*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // h5r1S (1:23905)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                          child: Text(
                            'Повторный вход',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              letterSpacing: 0.1800000072*fem,
                              color: Color(0xdd000000),
                            ),
                          ),
                        ),
                        Container(
                          // subtitle1MTz (1:23906)
                          constraints: BoxConstraints (
                            maxWidth: 299*fem,
                          ),
                          child: Text(
                            'Откажите гостю во входе, объяснив ситуацию. При необходимости, пригласите менеджера входной группы.',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              letterSpacing: 0.150000006*fem,
                              color: Color(0xdd000000),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // inputfUg (I1:25770;5904:28130)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 82*fem),
                    padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6.5*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // labelP9n (I1:25770;5904:28131)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5.5*fem),
                          child: Text(
                            'Транзакции',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              letterSpacing: 0.150000006*fem,
                              color: Color(0x60000000),
                            ),
                          ),
                        ),
                        Container(
                          // contenthgG (I1:25770;5904:28132)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5.5*fem),
                          width: double.infinity,
                          height: 72*fem,
                          child: Container(
                            // autogroupgf2uSNx (2ggqSdixMHpoYWsGFEgf2U)
                            width: 270*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // valueBbS (I1:25770;5904:28136)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 270*fem,
                                      height: 72*fem,
                                      child: Text(
                                        '28.04 10:47 Online-продажа\n30.04 10:13 Вход (12 Новицкий)\n30.04 10:14 Повтор (13 Тихонова)',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 16*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.5*ffem/fem,
                                          letterSpacing: 0.150000006*fem,
                                          color: Color(0x60000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // helpertextrha (I1:25770;5904:28142;11140:154887)
                                  left: 0*fem,
                                  top: 37*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 63*fem,
                                      height: 20*fem,
                                      child: Text(
                                        'Helper text',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.6600000064*ffem/fem,
                                          letterSpacing: 0.400000006*fem,
                                          color: Color(0x60000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // buttonwU8 (1:23910)
                    margin: EdgeInsets.fromLTRB(86*fem, 0*fem, 86*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: double.infinity,
                        height: 30*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff2d9cdb),
                          borderRadius: BorderRadius.circular(4*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x33000000),
                              offset: Offset(0*fem, 3*fem),
                              blurRadius: 0.5*fem,
                            ),
                            BoxShadow(
                              color: Color(0x23000000),
                              offset: Offset(0*fem, 2*fem),
                              blurRadius: 1*fem,
                            ),
                            BoxShadow(
                              color: Color(0x1e000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 2.5*fem,
                            ),
                          ],
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              // baseNZS (I1:23910;5903:24607)
                              left: 52.5*fem,
                              top: 4*fem,
                              child: Container(
                                width: 69*fem,
                                height: 22*fem,
                                child: Container(
                                  // autogroupbh1vJT6 (2ggq5tpWh2dpoiVXNkbH1v)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                                  width: 51*fem,
                                  height: double.infinity,
                                  child: Text(
                                    'НАЗАД',
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 13*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.6923076923*ffem/fem,
                                      letterSpacing: 0.4600000083*fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // buttonmba (1:25851)
                              left: 0*fem,
                              top: 0*fem,
                              child: TextButton(
                                onPressed: () {},
                                style: TextButton.styleFrom (
                                  padding: EdgeInsets.zero,
                                ),
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(52.5*fem, 4*fem, 34.5*fem, 4*fem),
                                  width: 156*fem,
                                  height: 30*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xff2d9cdb),
                                    borderRadius: BorderRadius.circular(4*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x33000000),
                                        offset: Offset(0*fem, 3*fem),
                                        blurRadius: 0.5*fem,
                                      ),
                                      BoxShadow(
                                        color: Color(0x23000000),
                                        offset: Offset(0*fem, 2*fem),
                                        blurRadius: 1*fem,
                                      ),
                                      BoxShadow(
                                        color: Color(0x1e000000),
                                        offset: Offset(0*fem, 1*fem),
                                        blurRadius: 2.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Container(
                                    // baseoYG (I1:25851;5903:24607)
                                    width: double.infinity,
                                    height: double.infinity,
                                    child: Container(
                                      // autogrouphcuaAtc (2ggqCZJ5PjrSGk7dEHHCua)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                                      padding: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                                      width: 51*fem,
                                      height: double.infinity,
                                      child: Text(
                                        'НАЗАД',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 13*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.6923076923*ffem/fem,
                                          letterSpacing: 0.4600000083*fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}