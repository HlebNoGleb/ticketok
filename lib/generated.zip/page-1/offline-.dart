import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // offlineYRA (1:23595)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffcfcfc),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // toparegularaflatrgk (1:23596)
              padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 16*fem),
              width: double.infinity,
              height: 56*fem,
              decoration: BoxDecoration (
                color: Color(0xff2196f3),
              ),
              child: Container(
                // autogroupv65an4c (2ggsLVjZeZJD94h6uvV65A)
                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 129*fem, 0*fem),
                width: 199*fem,
                height: double.infinity,
                child: Center(
                  child: Text(
                    'Работа с билетами',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.2*ffem/fem,
                      letterSpacing: 0.150000006*fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // autogroup64ua3WL (2ggs3b453QQdhFoNWU64uA)
              padding: EdgeInsets.fromLTRB(35.5*fem, 10*fem, 34.5*fem, 95*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // buttonmhE (1:25891)
                    margin: EdgeInsets.fromLTRB(58*fem, 0*fem, 58*fem, 178*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(5*fem, 8*fem, 3*fem, 8*fem),
                        width: double.infinity,
                        height: 42*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(4*fem),
                        ),
                        child: Container(
                          // baseFsJ (I1:25891;5903:25926)
                          padding: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 0*fem),
                          width: double.infinity,
                          height: double.infinity,
                          child: Text(
                            'ЗАВЕРШИТЬ СМЕНУ',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.7333333333*ffem/fem,
                              letterSpacing: 0.4600000083*fem,
                              color: Color(0xffd32f2f),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // frame9LNx (1:23601)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 58*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // h5UEG (1:23602)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                          child: Text(
                            'Сканер в offline',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              letterSpacing: 0.1800000072*fem,
                              color: Color(0xdd000000),
                            ),
                          ),
                        ),
                        Container(
                          // subtitle1NKe (1:23603)
                          constraints: BoxConstraints (
                            maxWidth: 290*fem,
                          ),
                          child: Text(
                            'для продолжения работы подключите\nустройство к сети',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1725*ffem/fem,
                              letterSpacing: 0.150000006*fem,
                              color: Color(0xdd000000),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // fab5E4 (1:23600)
                    margin: EdgeInsets.fromLTRB(21.5*fem, 0*fem, 23.5*fem, 15*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(27*fem, 0*fem, 27*fem, 0*fem),
                        width: double.infinity,
                        height: 50*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffbdbdbd),
                          borderRadius: BorderRadius.circular(100*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x33000000),
                              offset: Offset(0*fem, 3*fem),
                              blurRadius: 2.5*fem,
                            ),
                            BoxShadow(
                              color: Color(0x23000000),
                              offset: Offset(0*fem, 6*fem),
                              blurRadius: 5*fem,
                            ),
                            BoxShadow(
                              color: Color(0x1e000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 9*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // baseV2t (I1:23600;10003:114885)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'ВВЕСТИ ID ВРУЧНУЮ',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.7333333333*ffem/fem,
                                letterSpacing: 0.4600000083*fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // fabmWC (1:23599)
                    margin: EdgeInsets.fromLTRB(21.5*fem, 0*fem, 23.5*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(37.5*fem, 0*fem, 37.5*fem, 0*fem),
                        width: double.infinity,
                        height: 50*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffbdbdbd),
                          borderRadius: BorderRadius.circular(100*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x33000000),
                              offset: Offset(0*fem, 3*fem),
                              blurRadius: 2.5*fem,
                            ),
                            BoxShadow(
                              color: Color(0x23000000),
                              offset: Offset(0*fem, 6*fem),
                              blurRadius: 5*fem,
                            ),
                            BoxShadow(
                              color: Color(0x1e000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 9*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // basezNx (I1:23599;10003:114885)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'ОТКРЫТЬ СКАНЕР',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.7333333333*ffem/fem,
                                letterSpacing: 0.4600000083*fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}