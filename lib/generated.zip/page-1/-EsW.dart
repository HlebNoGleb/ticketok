import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_application_1/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // S3W (1:22879)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffcfcfc),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // toparegularaflatwkx (1:22880)
              padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 16*fem),
              width: double.infinity,
              height: 56*fem,
              decoration: BoxDecoration (
                color: Color(0xff2196f3),
              ),
              child: Container(
                // autogrouphhdwTUQ (2ggiZR2VDs5tjj8zUJHhdW)
                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 129*fem, 0*fem),
                width: 199*fem,
                height: double.infinity,
                child: Center(
                  child: Text(
                    'Работа с билетами',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.2*ffem/fem,
                      letterSpacing: 0.150000006*fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupdv1ei9S (2ggiGFrQmLMGWgQnJDDV1e)
              padding: EdgeInsets.fromLTRB(47.5*fem, 10*fem, 47.5*fem, 95*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // buttondnC (1:23779)
                    margin: EdgeInsets.fromLTRB(46*fem, 0*fem, 45*fem, 188*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(5*fem, 8*fem, 3*fem, 8*fem),
                        width: double.infinity,
                        height: 42*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(4*fem),
                        ),
                        child: Container(
                          // baseioe (I1:23779;5903:25926)
                          padding: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 0*fem),
                          width: double.infinity,
                          height: double.infinity,
                          child: Text(
                            'ЗАВЕРШИТЬ СМЕНУ',
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.7333333333*ffem/fem,
                              letterSpacing: 0.4600000083*fem,
                              color: Color(0xffd32f2f),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // frame9ce8 (1:23568)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 86*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // h5Yng (1:23566)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                          child: Text(
                            'Отсканируйте билет',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1*ffem/fem,
                              letterSpacing: 0.1800000072*fem,
                              color: Color(0xdd000000),
                            ),
                          ),
                        ),
                        Text(
                          // subtitle1T8x (1:23567)
                          'или введите ID вручную',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.150000006*fem,
                            color: Color(0xdd000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // fabP2c (1:23555)
                    margin: EdgeInsets.fromLTRB(9.5*fem, 0*fem, 10.5*fem, 15*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(27*fem, 0*fem, 27*fem, 0*fem),
                        width: double.infinity,
                        height: 50*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff56ccf2),
                          borderRadius: BorderRadius.circular(100*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x33000000),
                              offset: Offset(0*fem, 3*fem),
                              blurRadius: 2.5*fem,
                            ),
                            BoxShadow(
                              color: Color(0x23000000),
                              offset: Offset(0*fem, 6*fem),
                              blurRadius: 5*fem,
                            ),
                            BoxShadow(
                              color: Color(0x1e000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 9*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // basenqS (I1:23555;10003:114885)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'ВВЕСТИ ID ВРУЧНУЮ',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.7333333333*ffem/fem,
                                letterSpacing: 0.4600000083*fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // fabgA8 (1:23431)
                    margin: EdgeInsets.fromLTRB(9.5*fem, 0*fem, 10.5*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(37.5*fem, 0*fem, 37.5*fem, 0*fem),
                        width: double.infinity,
                        height: 50*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff2196f3),
                          borderRadius: BorderRadius.circular(100*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x33000000),
                              offset: Offset(0*fem, 3*fem),
                              blurRadius: 2.5*fem,
                            ),
                            BoxShadow(
                              color: Color(0x23000000),
                              offset: Offset(0*fem, 6*fem),
                              blurRadius: 5*fem,
                            ),
                            BoxShadow(
                              color: Color(0x1e000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 9*fem,
                            ),
                          ],
                        ),
                        child: Container(
                          // basegJY (I1:23431;10003:114885)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(100*fem),
                          ),
                          child: Center(
                            child: Text(
                              'ОТКРЫТЬ СКАНЕР',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 15*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.7333333333*ffem/fem,
                                letterSpacing: 0.4600000083*fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}